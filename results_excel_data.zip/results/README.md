# Numerical results

Subfolders use the same numbered analysis names as graphs/ and code/.

- PSD CSVs contain frequency and acceleration power density, in (m/s²)²/Hz.
- FFT CSVs contain frequency and one-sided acceleration amplitude, in m/s².
- Feature CSVs contain RMS, peaks, crest factor, Pearson kurtosis and exploratory frequency-band summaries, depending on the analysis.
- Generated signal CSVs contain measured, deterministic sine, Gaussian and synthetic components where applicable.
- Parameter and quality JSON files record source provenance, timing gaps, sample rates, settings and fixed random seeds.
- validation.json files report numerical checks for the analyses with dedicated validators.

These results do not include a trained fault classifier or independent-flight accuracy. Definitions and limits are documented in ../docs/METHODS.md.
