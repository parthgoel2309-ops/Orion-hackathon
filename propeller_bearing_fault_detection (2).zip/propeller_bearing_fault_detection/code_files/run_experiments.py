"""
run_experiments.py  -  all numerical results for the report.

    python run_experiments.py                     # everything, 30 seeds per class and noise level  (~3-4 min)
    python run_experiments.py --seeds 10          # quick version
    python run_experiments.py --skip-sweep        # only the noise study
    python run_experiments.py --skip-noise        # only the severity x RPM study

Part 1 (noise study, deliverable 5):  accuracy vs sensor noise, confusion matrices, confidence reliability,
                                      check of the processing-gain formula (Eq. 6)
Part 2 (severity x RPM study):        where imbalance vs misalignment stops being separable from vibration alone

Writes into the current folder (or --outdir):
    noise_sweep.png, snr_validation.png, results_sweep.csv, results_summary.txt
    sweep_severity_rpm.png, results_severity_rpm.txt
Seeds: 1000+ for the noise study, 2000+ for the severity x RPM study (never used for tuning thresholds).
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from collections import Counter
from scipy import signal
from gen_signal import gen_signal, accelerance
from classify import classify
from params import P, derived

SIGMAS = [0.05, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0]      # sensor noise std [m/s^2]
TRUE = {"healthy": "healthy", "imbalance": "imbalance", "misalignment": "misalignment",
        "bearing_outer": "bearing", "bearing_inner": "bearing", "bearing_ball": "bearing"}
LABELS = ["healthy", "imbalance", "misalignment", "bearing"]
BEARING_KINDS = ["bearing_outer", "bearing_inner", "bearing_ball"]


def rect_bin_snr_db(sig, f0):
    """empirical bin SNR of the radial tone with a RECTANGULAR window (the assumption behind Eq. 6)."""
    fs = sig["fs"]
    x = signal.sosfiltfilt(signal.butter(4, 10.0, btype="highpass", fs=fs, output="sos"), sig["ax"] - sig["ax"].mean())
    X = np.abs(np.fft.rfft(x)) ** 2
    f = np.fft.rfftfreq(len(x), 1 / fs)
    k = int(np.argmin(np.abs(f - f0)))
    noise = (f > 0.7 * f0) & (f < 1.3 * f0) & (np.abs(f - f0) > 6) & (np.abs(f - 2 * f0) > 6)
    noise &= (np.abs(f - 0.5 * f0) > 6)
    # the bin holds signal + noise power: subtract the noise power so the result is S/N like Eq. 6 (matters below ~6 dB)
    return 10 * np.log10(max(X[k] / np.mean(X[noise]) - 1.0, 1e-3))


def theory_bin_snr_db(sigma, n):
    """Eq. (6): (A^2 / 2 sigma^2) * N/2 for the imbalance tone on ONE axis."""
    d = derived()
    A = abs(accelerance(np.array([d["f0"]]), d, P)[0]) * d["F_imb"]
    return 10 * np.log10(A**2 / (2 * sigma**2) * n / 2), A


# ======================================================================================= part 1: noise study
def main(n_seeds=30, sigmas=SIGMAS, outdir="."):
    os.makedirs(outdir, exist_ok=True)
    rows = []          # (sigma, true, pred, confidence, seed)
    emp = {s: [] for s in sigmas}
    for sg in sigmas:
        for tname in ["healthy", "imbalance", "misalignment", "bearing"]:
            for sd in range(n_seeds):
                kind = tname if tname != "bearing" else BEARING_KINDS[sd % 3]
                sig = gen_signal(kind, seed=1000 + sd, sigma=sg)
                r = classify(sig["ax"], sig["ay"], sig["az"], sig["fs"])
                rows.append((sg, tname, r["label"], r["confidence"], sd))
                if tname == "imbalance":
                    emp[sg].append(rect_bin_snr_db(sig, sig["f0"]))
        print(f"sigma={sg:5.2f} done", flush=True)

    R = np.array([(r[0], r[3]) for r in rows])
    true = np.array([r[1] for r in rows]); pred = np.array([r[2] for r in rows]); conf = R[:, 1]; sgs = R[:, 0]
    np.savetxt(os.path.join(outdir, "results_sweep.csv"),
               np.array([(r[0], r[1], r[2], f"{r[3]:.3f}", r[4]) for r in rows], dtype=object),
               delimiter=",", fmt="%s", header="sigma,true,pred,confidence,seed", comments="")

    out = []
    # ---------- accuracy vs noise
    acc = {c: [np.mean(pred[(true == c) & (sgs == s)] == c) for s in sigmas] for c in LABELS}
    overall = [np.mean(pred[sgs == s] == true[sgs == s]) for s in sigmas]
    mconf = [np.mean(conf[sgs == s]) for s in sigmas]
    n_bin_theory = [theory_bin_snr_db(s, int(P["T"] * P["fs"]))[0] for s in sigmas]
    out.append(f"{n_seeds} windows per class and noise level (bearing = outer/inner/ball in equal parts)\n")
    out.append("sigma  binSNR[dB]  " + "  ".join(f"{c[:6]:>7s}" for c in LABELS) + "  overall  mean-conf")
    for i, s in enumerate(sigmas):
        out.append(f"{s:5.2f}  {n_bin_theory[i]:9.1f}   " + "  ".join(f"{acc[c][i]:7.2f}" for c in LABELS)
                   + f"  {overall[i]:7.2f}  {mconf[i]:8.2f}")
    out.append("(binSNR = Eq. 6 for the imbalance radial tone on one axis)\n")

    # ---------- confusion matrices at lowest noise and at a mid noise
    for s in (sigmas[0], 0.5 if 0.5 in sigmas else sigmas[len(sigmas) // 2], 1.0 if 1.0 in sigmas else sigmas[-3]):
        m = np.zeros((4, 4), int)
        for i, t in enumerate(LABELS):
            for j, p in enumerate(LABELS):
                m[i, j] = np.sum((true == t) & (pred == p) & (sgs == s))
        out.append(f"confusion matrix, sigma = {s}   (rows = true, cols = predicted)")
        out.append("              " + "".join(f"{l[:8]:>10s}" for l in LABELS))
        for i, t in enumerate(LABELS):
            out.append(f"{t:14s}" + "".join(f"{m[i, j]:10d}" for j in range(4)))
        out.append("")

    # ---------- confidence reliability (pooled over all noise levels)
    edges = [0, 0.2, 0.4, 0.6, 0.8, 1.0001]
    for title, mask in (("FAULT calls (predicted imbalance / misalignment / bearing)", pred != "healthy"),
                        ("HEALTHY calls (accuracy here depends on the noise level: a fault below the detection limit "
                         "also reads as healthy, see evidence['detection_limit_radial'])", pred == "healthy")):
        out.append(f"confidence reliability, {title}, all noise levels pooled")
        out.append("confidence bin   windows   accuracy")
        for lo, hi in zip(edges[:-1], edges[1:]):
            sel = mask & (conf >= lo) & (conf < hi)
            a = np.mean(pred[sel] == true[sel]) if sel.any() else np.nan
            out.append(f"  {lo:.1f} - {min(hi, 1.0):.1f}      {int(sel.sum()):6d}     {a:.2f}" if sel.any()
                       else f"  {lo:.1f} - {min(hi, 1.0):.1f}      {0:6d}       -")
        out.append("")

    # ---------- Eq. 6 validation
    out.append("Eq. 6 check (imbalance radial tone, rectangular window):  sigma | theory dB | empirical dB (mean of seeds)")
    th_emp = []
    for s in sigmas:
        th, A = theory_bin_snr_db(s, int(P["T"] * P["fs"]))
        e = 10 * np.log10(np.mean(10 ** (np.array(emp[s]) / 10)))
        th_emp.append((th, e))
        out.append(f"  {s:5.2f} | {th:7.1f} | {e:7.1f}")
    txt = "\n".join(out)
    print("\n" + txt)
    open(os.path.join(outdir, "results_summary.txt"), "w").write(txt)

    # ---------- plots
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
    for c in LABELS:
        ax[0].plot(sigmas, acc[c], "o-", label=c)
    ax[0].plot(sigmas, overall, "k--", lw=2, label="overall")
    ax[0].set_xscale("log"); ax[0].set_ylim(-0.02, 1.05)
    ax[0].set_xlabel("sensor noise std  $\\sigma$ [m/s$^2$]"); ax[0].set_ylabel("fraction classified correctly")
    ax[0].set_title("Detection extent vs noise"); ax[0].grid(alpha=0.3, which="both"); ax[0].legend(fontsize=8)
    ax[1].plot(sigmas, mconf, "s-", color="tab:purple")
    ax[1].set_xscale("log"); ax[1].set_ylim(0, 1)
    ax[1].set_xlabel("sensor noise std  $\\sigma$ [m/s$^2$]"); ax[1].set_ylabel("mean confidence")
    ax[1].set_title("Mean confidence vs noise"); ax[1].grid(alpha=0.3, which="both")
    fig.tight_layout(); fig.savefig(os.path.join(outdir, "noise_sweep.png"), dpi=130); plt.close(fig)

    fig, a = plt.subplots(figsize=(5.2, 4.8))
    th = np.array([t for t, _ in th_emp]); em = np.array([e for _, e in th_emp])
    a.plot(th, em, "o-", label="simulation (rect. window)")
    lim = [min(th.min(), em.min()) - 2, max(th.max(), em.max()) + 2]
    a.plot(lim, lim, "k--", label="Eq. 6 (y = x)")
    a.set_xlabel("theoretical bin SNR [dB]"); a.set_ylabel("measured bin SNR [dB]")
    a.set_title("Processing-gain check (imbalance 1x tone)"); a.grid(alpha=0.3); a.legend()
    fig.tight_layout(); fig.savefig(os.path.join(outdir, "snr_validation.png"), dpi=130); plt.close(fig)


# ======================================================================================= part 2: severity x RPM
def sweep_severity_rpm(n_seeds=10, sigma=None, outdir="."):
    """Imbalance (severity U = m_u*r) and misalignment (bend angle) over a range of severities and RPMs.
    Shows where the axial-2x / radial-1x test (the only vibration-only discriminator between the two) breaks down."""
    os.makedirs(outdir, exist_ok=True)
    sigma = P["sigma"] if sigma is None else sigma
    rpms = [3000, 4500, 6000, 7500, 9000]
    studies = [("imbalance", "U_fault", [1e-6, 2e-6, 5e-6, 1e-5], "imbalance  m_u*r [g*mm]", 1e6),
               ("misalignment", "alpha_deg", [0.25, 0.5, 1.0, 2.0], "bend angle [deg]", 1.0)]
    out = [f"severity x RPM study, sigma = {sigma} m/s^2, {n_seeds} windows per cell.",
           "cell = fraction classified as the TRUE class (dominant wrong label in brackets)\n"]
    fig, axs = plt.subplots(1, 2, figsize=(12, 4.3))
    for ax, (kind, key, vals, ylabel, scale) in zip(axs, studies):
        acc = np.zeros((len(vals), len(rpms)))
        wrong = [["" for _ in rpms] for _ in vals]
        for i, v in enumerate(vals):
            for j, rpm in enumerate(rpms):
                preds = []
                for sd in range(n_seeds):
                    s = gen_signal(kind, seed=2000 + sd, sigma=sigma, rpm=float(rpm), **{key: v})
                    preds.append(classify(s["ax"], s["ay"], s["az"], s["fs"])["label"])
                acc[i, j] = np.mean([p == kind for p in preds])
                bad = Counter(p for p in preds if p != kind)
                wrong[i][j] = bad.most_common(1)[0][0][:5] if bad else ""
            print(f"  {kind}: {key}={v} done", flush=True)
        out.append(f"{kind}   (rows: {ylabel}, columns: RPM)")
        out.append("            " + "".join(f"{r:>14d}" for r in rpms))
        for i, v in enumerate(vals):
            out.append(f"{v * scale:9.3g}   " + "".join(
                f"{acc[i, j]:8.2f}" + (f" [{wrong[i][j]}]" if wrong[i][j] else "").ljust(6) for j in range(len(rpms))))
        out.append("")
        im = ax.imshow(acc, origin="lower", vmin=0, vmax=1, cmap="RdYlGn", aspect="auto")
        ax.set_xticks(range(len(rpms))); ax.set_xticklabels(rpms)
        ax.set_yticks(range(len(vals))); ax.set_yticklabels([f"{v * scale:g}" for v in vals])
        ax.set_xlabel("RPM"); ax.set_ylabel(ylabel); ax.set_title(f"{kind}: fraction classified correctly")
        for i in range(len(vals)):
            for j in range(len(rpms)):
                ax.text(j, i, f"{acc[i, j]:.1f}", ha="center", va="center", fontsize=9)
    fig.tight_layout(); fig.savefig(os.path.join(outdir, "sweep_severity_rpm.png"), dpi=130); plt.close(fig)
    txt = "\n".join(out)
    print("\n" + txt)
    open(os.path.join(outdir, "results_severity_rpm.txt"), "w").write(txt)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="numerical results for the report")
    ap.add_argument("--seeds", type=int, default=30, help="windows per class and noise level (noise study)")
    ap.add_argument("--sweep-seeds", type=int, default=10, help="windows per cell (severity x RPM study)")
    ap.add_argument("--outdir", default=".")
    ap.add_argument("--skip-noise", action="store_true")
    ap.add_argument("--skip-sweep", action="store_true")
    a = ap.parse_args()
    if not a.skip_noise:
        main(n_seeds=a.seeds, outdir=a.outdir)
    if not a.skip_sweep:
        sweep_severity_rpm(n_seeds=a.sweep_seeds, outdir=a.outdir)
