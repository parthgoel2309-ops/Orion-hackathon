"""
plot_spectra.py  -  generate one window per class, save CSVs, plot the spectra.

    python plot_spectra.py            ->  sim_data/*.csv, spectra_lowfreq.png, spectra_bearing.png
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import signal
from gen_signal import gen_signal, save_csv
from params import derived

BAND = (1000.0, 3000.0)   # band-pass around the chassis resonance (f_res = 1500 Hz in params.py)


HP_HZ = 10.0   # high-pass used before the FFT: removes gravity and the slow rigid-body wander (same step the classifier will use)


def amp_spectrum(x, fs, hp=HP_HZ):
    """Single-sided amplitude spectrum [m/s^2]: mean removed, 4th-order high-pass at hp [Hz] (None = off), Hann window."""
    x = np.asarray(x, float) - np.mean(x)
    if hp:
        x = signal.sosfiltfilt(signal.butter(4, hp, btype="highpass", fs=fs, output="sos"), x)
    w = np.hanning(len(x))
    X = np.abs(np.fft.rfft(x * w)) * 2 / np.sum(w)
    return np.fft.rfftfreq(len(x), 1 / fs), X


def envelope_spectrum(x, fs, band=BAND):
    """band-pass -> Hilbert envelope -> remove mean -> FFT   (steps 1-5 of the doc)."""
    sos = signal.butter(4, band, btype="bandpass", fs=fs, output="sos")
    xf = signal.sosfiltfilt(sos, np.asarray(x, float) - np.mean(x))
    e = np.abs(signal.hilbert(xf))
    e = e - e.mean()
    w = np.hanning(len(e))
    return np.fft.rfftfreq(len(e), 1 / fs), np.abs(np.fft.rfft(e * w)) * 2 / np.sum(w)


def main(seed=1, outdir="."):
    d = derived()
    f0 = d["f0"]
    os.makedirs(os.path.join(outdir, "sim_data"), exist_ok=True)
    classes = ["healthy", "imbalance", "misalignment", "bearing_outer", "bearing_inner", "bearing_ball"]
    sigs = {c: gen_signal(c, seed=seed) for c in classes}
    for c, s in sigs.items():
        save_csv(s, os.path.join(outdir, "sim_data", f"{c}.csv"))

    # ---------- Figure 1: low-frequency spectra (1x / 2x region) ----------
    show = ["healthy", "imbalance", "misalignment", "bearing_outer"]
    fig, axs = plt.subplots(len(show), 2, figsize=(11, 9), sharex=True, sharey=True)
    for i, c in enumerate(show):
        s = sigs[c]
        fr, Xx = amp_spectrum(s["ax"], s["fs"])
        _, Xy = amp_spectrum(s["ay"], s["fs"])
        _, Xz = amp_spectrum(s["az"], s["fs"])
        Xr = np.sqrt(Xx**2 + Xy**2)
        for j, (X, name) in enumerate([(Xr, "radial  sqrt(ax$^2$+ay$^2$)"), (Xz, "axial  az")]):
            a = axs[i, j]
            a.semilogy(fr, X, lw=0.8)
            for k, col in ((1, "tab:red"), (2, "tab:green")):
                a.axvline(k * f0, color=col, ls="--", lw=0.8, alpha=0.7)
            a.set_xlim(0, 700)
            a.set_ylim(1e-3, 2e-1)
            a.set_title(f"{c}  -  {name}", fontsize=9)
            a.grid(alpha=0.3, which="both")
    axs[-1, 0].set_xlabel("frequency [Hz]")
    axs[-1, 1].set_xlabel("frequency [Hz]")
    for a in axs[:, 0]:
        a.set_ylabel("amplitude [m/s$^2$]")
    fig.suptitle(f"Simulated accelerometer spectra  (red = 1$\\Omega$ = {f0:.0f} Hz, green = 2$\\Omega$ = {2*f0:.0f} Hz)", fontsize=11)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "spectra_lowfreq.png"), dpi=130)
    plt.close(fig)

    # ---------- Figure 2: bearing faults - raw spectrum and envelope spectrum ----------
    marks = {"bearing_outer": ("f_o", d["f_o"]), "bearing_inner": ("f_i", d["f_i"]), "bearing_ball": ("2 f_b", 2 * d["f_b"])}
    fig, axs = plt.subplots(3, 2, figsize=(11, 8.5))
    for i, c in enumerate(marks):
        s = sigs[c]
        fr, Xx = amp_spectrum(s["ax"], s["fs"])
        axs[i, 0].semilogy(fr, Xx, lw=0.6)
        axs[i, 0].axvspan(*BAND, color="orange", alpha=0.15, label="band-pass")
        axs[i, 0].set_xlim(0, s["fs"] / 2)
        axs[i, 0].set_title(f"{c} - raw spectrum (ax)", fontsize=9)
        axs[i, 0].set_ylabel("m/s$^2$")
        axs[i, 0].grid(alpha=0.3, which="both")
        fe, Ex = envelope_spectrum(s["ax"], s["fs"])
        _, Ey = envelope_spectrum(s["ay"], s["fs"])
        E = np.sqrt(Ex**2 + Ey**2)
        axs[i, 1].plot(fe, E, lw=0.7)
        lab, fx = marks[c]
        for h in (1, 2, 3):
            axs[i, 1].axvline(h * fx, color="tab:red", ls="--", lw=0.8, alpha=0.7)
        axs[i, 1].set_xlim(0, 1000)
        axs[i, 1].set_title(f"{c} - envelope spectrum (red: {lab} and harmonics)", fontsize=9)
        axs[i, 1].grid(alpha=0.3)
    axs[-1, 0].set_xlabel("frequency [Hz]")
    axs[-1, 1].set_xlabel("frequency [Hz]")
    axs[0, 0].legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "spectra_bearing.png"), dpi=130)
    plt.close(fig)

    print(f"f0={f0:.1f} Hz  f_o={d['f_o']:.1f}  f_i={d['f_i']:.1f}  2f_b={2*d['f_b']:.1f}  f_c={d['f_c']:.1f}")
    print(f"force amplitudes [N]: imbalance {d['F_imb']:.2f} | misalign radial F1 {d['F1']:.2f} "
          f"(couple {d['F1_couple']:.2f} + thrust {d['F1_thrust']:.3f}) | misalign axial F2 {d['F2']:.2f} | BPF {d['F_bpf']:.2f}")


if __name__ == "__main__":
    main()
