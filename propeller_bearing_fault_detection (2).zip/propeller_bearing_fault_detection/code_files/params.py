"""
params.py  -  every simulation parameter in one place.

ALL VALUES ARE ASSUMED / ILLUSTRATIVE (nothing here is measured).
Change them here, nowhere else.  SI units unless stated.
"""
import numpy as np

P = dict(
    # ---------------- IMU / sampling ----------------
    fs=8000.0,            # IMU output sample rate [Hz]
    fs_sim_factor=4,      # internal simulation rate = fs * this (impulses/jitter finer than 1 IMU sample)
    imu_lpf_hz=3000.0,    # IMU internal low-pass (anti-alias) corner [Hz]
    T=1.0,                # analysis window length [s]
    lsb=4.8e-3,           # accelerometer resolution [m/s^2] (~ +-16 g, 16 bit); 0 to disable quantisation
    sigma=0.05,           # white Gaussian sensor noise, std per axis [m/s^2]

    # ---------------- operating point ----------------
    rpm=6000.0,           # motor RPM, same for all motors, constant in the window
    thrust=5.0,           # thrust of the faulty motor T [N]   (hover, ~2 kg quad)
    g=9.81,

    # ---------------- chassis: one SDOF accelerance FRF, Eq.(1) of the doc ----------------
    m_eq=0.2,             # equivalent structural mass [kg]
    f_res=1500.0,         # structural resonance [Hz]
    zeta=0.05,            # damping ratio  (c = 2*zeta*sqrt(k*m_eq))

    # ---------------- healthy baseline: blade-pass force, Eq.(3) ----------------
    kappa=0.05,           # BPF ripple coefficient  (F_bpf = kappa*T*sin(2*Omega*t + phi_b))
    phi_b=None,           # BPF phase [rad]; None = random per window. Misalignment Z-2Omega uses phi2 = phi_b

    # ---------------- propeller mass imbalance (severity = U = m_u*r) ----------------
    U_fault=5e-6,         # m_u * r  [kg*m]  (= 5 g*mm)

    # ---------------- shaft misalignment ----------------
    alpha_deg=1.0,        # bend angle [deg]
    Ip_minus_It=2.5e-6,   # polar - transverse inertia of rotor+prop [kg*m^2]
    Lb=0.012,             # bearing spacing [m]
    dk_lat=2500.0,        # lateral stiffness anisotropy [N/m]
    L_eff=0.02,           # effective lever arm [m]   -> F2 = dk_lat*L_eff*alpha  (>> kappa*T)

    # ---------------- bearing ----------------
    Z=7, d_over_D=0.3, contact_angle=0.0,   # deep-groove ball bearing, alpha ~ 0
    m_ball=1.1e-4,        # rolling element mass [kg]  (~3 mm steel ball)
    c_k=1.0,              # kinematic constant in v_impact = c_k*Omega*w_d
    w_d=0.5e-3,           # spall width [m]  (severity)
    jitter=0.015,         # random slip jitter, std as fraction of the fault interval
    load_mod=0.5,         # inner-race load-zone modulation depth  (1 + mu*cos(Omega t))

    # ---------------- harmonic content (realism add-on, NOT in the theory doc) ----------------
    harm_decay=0.15,      # force at order k has amplitude ~ harm_decay^(k-1) of the fundamental; 0 = pure sinusoids
    n_harm=3,             # number of orders generated (radial: 1x,2x,3x ; axial: 2x,4x,6x)

    # ---------------- slow rigid-body motion (what a real IMU also sees) ----------------
    rigid_amp=0.15,       # amplitude of slow manoeuvre wander [m/s^2]
)


def derived(p=P):
    """Quantities computed from the parameters above."""
    d = {}
    d["f0"] = p["rpm"] / 60.0
    d["Omega"] = 2 * np.pi * d["f0"]
    Z, r, a = p["Z"], p["d_over_D"], p["contact_angle"]
    f0 = d["f0"]
    d["f_i"] = Z / 2 * f0 * (1 + r * np.cos(a))
    d["f_o"] = Z / 2 * f0 * (1 - r * np.cos(a))
    d["f_b"] = 1 / (2 * r) * f0 * (1 - r**2 * np.cos(a) ** 2)   # D/(2d) = 1/(2 d/D)
    d["f_c"] = f0 / 2 * (1 - r * np.cos(a))                      # cage frequency
    assert abs(d["f_i"] + d["f_o"] - Z * f0) < 1e-9              # kinematic unit test from the doc
    # chassis
    wn = 2 * np.pi * p["f_res"]
    d["k"] = p["m_eq"] * wn**2
    d["c"] = 2 * p["zeta"] * np.sqrt(d["k"] * p["m_eq"])
    # force amplitudes
    al = np.deg2rad(p["alpha_deg"])
    d["F_imb"] = p["U_fault"] * d["Omega"] ** 2
    d["F1"] = p["Ip_minus_It"] * np.sin(al) * np.cos(al) * d["Omega"] ** 2 / p["Lb"] + p["thrust"] * np.sin(al)
    d["F1_couple"] = p["Ip_minus_It"] * np.sin(al) * np.cos(al) * d["Omega"] ** 2 / p["Lb"]
    d["F1_thrust"] = p["thrust"] * np.sin(al)
    d["F2"] = p["dk_lat"] * p["L_eff"] * al
    d["F_bpf"] = p["kappa"] * p["thrust"]
    d["v_impact"] = p["c_k"] * d["Omega"] * p["w_d"]
    d["I_impact"] = 2 * p["m_ball"] * d["v_impact"]              # Eq.(15) of the doc
    return d


if __name__ == "__main__":
    for k, v in derived().items():
        print(f"{k:10s} = {v:.6g}")
