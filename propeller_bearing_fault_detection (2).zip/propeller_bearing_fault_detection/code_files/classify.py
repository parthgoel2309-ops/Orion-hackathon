"""
classify.py  -  fault detection + classification from RAW accelerometer arrays.

    from classify import classify
    r = classify(ax, ay, az, fs)          # no RPM, no units needed
    r["label"], r["confidence"], r["f0_hz"], r["evidence"]

Labels: "healthy", "imbalance", "misalignment", "bearing"

Design rules (so that it works on raw, un-normalised data with unknown RPM):
  * nothing depends on absolute amplitude: every test is a RATIO (peak / local noise floor,
    axial / radial, spectral kurtosis), so g, m/s^2 or raw ADC counts all work;
  * RPM is not given: f0 is ESTIMATED from the radial (ax, ay) spectrum;
  * decision order (as in the theory doc):
        1. bearing  : harmonic family in the ENVELOPE spectrum of the best band + impulsiveness (kurtosis) gate
                      (radial axes only: the model has Fz ~ 0 for bearing impacts, and the Z axis carries the
                       deterministic blade-pass harmonics whose beating would mimic a harmonic family)
        2. healthy  : no radial 1x peak
        3. radial 1x present:  axial(Z) 2x / radial 1x ratio high -> misalignment, low -> imbalance
  * confidence in [0, 1] is a heuristic evidence score (see conf()), NOT a calibrated probability.

Known limitation (vibration-only, no thrust / no healthy reference):
  the imbalance-vs-misalignment ratio test compares the (roughly fixed) blade-pass level in Z with a radial 1x tone
  that grows with imbalance severity and steeply with RPM. A weak imbalance, or a low RPM, can therefore be called
  misalignment. run_experiments.py measures this boundary (severity x RPM sweep).

Assumed sensor axes: x, y in the rotor plane, z along the thrust axis (as in the simulator).
"""
import numpy as np
from scipy import signal
from scipy.ndimage import median_filter, maximum_filter1d
from scipy.stats import kurtosis

CFG = dict(
    hp_hz=10.0,             # high-pass: removes gravity / slow rigid-body motion
    f0_range=(20.0, 400.0), # plausible shaft frequency search range [Hz]  (1200 - 24000 RPM)
    pfr_thr=3.5,            # radial 1x: peak-to-floor ratio (amplitude) needed to call the peak real (false alarm ~1e-5/window)
    pfr_thr_env=4.0,        # envelope spectrum: same idea (two harmonically related peaks are required, so this is safe)
    floor_hw_hz=40.0,       # half-width of the running-median noise-floor window [Hz]
    tol_bins=2,             # +- bins when looking for a peak at an expected frequency
    ratio_thr=1.0,          # axial(2x)/radial(1x): above -> misalignment, below -> imbalance
    # bearing
    bear_min_fs=3000.0,     # bearing check is skipped if fs is lower than this
    bear_axes="xy",         # axes used by the bearing branch: "xy" (radial only, matches the model) or "xyz"
    bear_band_frac=0.125,   # band-pass width as fraction of fs
    bear_lo_start=(0.05, 0.36, 0.05),   # candidate band lower edges (fraction of fs): start, stop, step
    bear_fmin=30.0, bear_fmax=1000.0,   # envelope-spectrum fault-frequency search range [Hz]
    bear_min_harm=2,        # number of harmonically related envelope peaks needed
    kurt_thr=0.3,           # impulsiveness gate: excess kurtosis of the WINNING band (noise ~0); None = off
)


# ----------------------------------------------------------------------------- helpers
def _prep(x, fs, hp):
    x = np.asarray(x, float)
    x = x - x.mean()
    if hp:
        x = signal.sosfiltfilt(signal.butter(4, hp, btype="highpass", fs=fs, output="sos"), x)
    return x


def _amp_spec(x, fs):
    """single-sided amplitude spectrum, Hann window."""
    w = np.hanning(len(x))
    return np.fft.rfftfreq(len(x), 1 / fs), np.abs(np.fft.rfft(x * w)) * 2 / w.sum()


def _floor(A, df, hw_hz):
    """running-median noise floor (robust to the few peaks inside the window)."""
    size = max(5, int(hw_hz / df) * 2 + 1)
    return median_filter(A, size=size, mode="nearest") + 1e-30


def _peak(arr, df, f, tol):
    """max of arr within +-tol bins around frequency f -> (value, bin index)."""
    i = int(round(f / df))
    lo, hi = max(i - tol, 0), min(i + tol + 1, len(arr))
    if lo >= hi:
        return 0.0, min(max(i, 0), len(arr) - 1)
    j = lo + int(np.argmax(arr[lo:hi]))
    return float(arr[j]), j


def _refine(A, j, df):
    """parabolic interpolation of a spectral peak -> frequency [Hz]."""
    if j <= 0 or j >= len(A) - 1:
        return j * df
    a, b, c = np.log(A[j - 1] + 1e-30), np.log(A[j] + 1e-30), np.log(A[j + 1] + 1e-30)
    den = a - 2 * b + c
    return (j + (0.5 * (a - c) / den if den != 0 else 0.0)) * df


def conf(margin, k=1.0):
    """evidence -> [0,1].  margin = ln(observed / threshold).  margin 0 -> 0, 0.7 -> 0.5 (k=1), 2.3 -> 0.9."""
    return float(1 - np.exp(-k * max(margin, 0.0)))


# ----------------------------------------------------------------------------- bearing branch
def _family(P, Pm, df, cfg):
    """best harmonic family in an envelope-spectrum PFR array -> (strength, f_fundamental, n_harmonics)."""
    thr, tol = cfg["pfr_thr_env"], cfg["tol_bins"]
    best = (0.0, None, 0)
    i0, i1 = max(int(cfg["bear_fmin"] / df), 1), min(int(cfg["bear_fmax"] / df), len(P) - 1)
    for i in range(i0, i1):
        if Pm[i] < thr or P[i] < P[i - 1] or P[i] < P[i + 1]:          # local peaks only
            continue
        hs = [P[i]]
        for h in range(2, 6):
            j = i * h
            if j + tol >= len(P):
                break
            if Pm[j] >= thr:
                hs.append(Pm[j])
        if len(hs) >= cfg["bear_min_harm"]:
            strength = float(np.sort(hs)[::-1][: cfg["bear_min_harm"]].min())   # weakest of the strongest peaks
            if strength > best[0]:
                best = (strength, i * df, len(hs))
    return best


def _bearing(axes, fs, cfg):
    """Scan candidate bands; in each: band-pass -> Hilbert envelope -> envelope spectrum -> harmonic family.
    The band with the strongest family wins. Impulsiveness (excess kurtosis OF THAT BAND) is used as a gate."""
    out = dict(checked=True, detected=False, band=None, f_env=None, harmonics=0, harm_pfr=0.0,
               kurt=0.0, peaks_hz=[])
    bw = cfg["bear_band_frac"] * fs
    kband = 0.0
    for lo in np.arange(*cfg["bear_lo_start"]) * fs:
        hi = min(lo + bw, 0.47 * fs)
        if hi - lo < 0.5 * bw:
            continue
        sos = signal.butter(4, [lo, hi], btype="bandpass", fs=fs, output="sos")
        xs = [signal.sosfiltfilt(sos, x) for x in axes]
        kb = max(float(kurtosis(x, fisher=True)) for x in xs)           # impulsiveness of THIS band
        Es = []
        for x in xs:
            e = np.abs(signal.hilbert(x))
            e = e - e.mean()
            fe, E = _amp_spec(e, fs)
            Es.append(E)
        E = np.sqrt(np.sum(np.square(Es), axis=0))
        df = fe[1] - fe[0]
        P = E / _floor(E, df, cfg["floor_hw_hz"])
        Pm = maximum_filter1d(P, size=2 * cfg["tol_bins"] + 1)
        strength, f_env, nh = _family(P, Pm, df, cfg)
        if strength > out["harm_pfr"]:
            sel = np.where((P >= cfg["pfr_thr_env"]) & (P >= np.roll(P, 1)) & (P >= np.roll(P, -1)))[0]
            sel = sel[(sel * df >= cfg["bear_fmin"]) & (sel * df <= 3 * cfg["bear_fmax"])]
            top = sel[np.argsort(P[sel])[::-1][:4]]
            out.update(band=(float(lo), float(hi)), harm_pfr=strength, f_env=float(f_env), harmonics=nh,
                       peaks_hz=[round(float(t * df), 1) for t in top])
            kband = kb
    out["kurt"] = float(kband)
    gate_ok = cfg["kurt_thr"] is None or kband > cfg["kurt_thr"]
    out["detected"] = bool(out["f_env"] is not None and gate_ok)
    return out


# ----------------------------------------------------------------------------- main entry
def classify(ax, ay, az, fs, **kw):
    cfg = dict(CFG)
    cfg.update(kw)
    thr = cfg["pfr_thr"]
    x, y, z = (_prep(a, fs, cfg["hp_hz"]) for a in (ax, ay, az))
    ev = {}

    # ---- 1. bearing (impulsive + periodic envelope), radial axes
    if fs >= cfg["bear_min_fs"]:
        b_axes = (x, y) if cfg["bear_axes"] == "xy" else (x, y, z)
        b = _bearing(b_axes, fs, cfg)
        ev["bearing"] = b
        if b["detected"]:
            return dict(label="bearing", confidence=conf(np.log(b["harm_pfr"] / cfg["pfr_thr_env"])), f0_hz=None, evidence=ev,
                        note=f"impulsive band {b['band'][0]:.0f}-{b['band'][1]:.0f} Hz, envelope peaks at "
                             f"{b['peaks_hz']} Hz (periodicity {b['f_env']:.1f} Hz, {b['harmonics']} harmonics)")
    else:
        ev["bearing"] = dict(checked=False)

    # ---- 2. radial 1x peak + f0 estimate (no RPM given)
    f, Ax = _amp_spec(x, fs)
    _, Ay = _amp_spec(y, fs)
    _, Az = _amp_spec(z, fs)
    df = f[1] - f[0]
    Ar = np.sqrt(Ax**2 + Ay**2)
    Pr = Ar / _floor(Ar, df, cfg["floor_hw_hz"])
    Pm = maximum_filter1d(Pr, size=2 * cfg["tol_bins"] + 1)
    lo, hi = int(cfg["f0_range"][0] / df), min(int(cfg["f0_range"][1] / df), len(Pr) // 3 - 1)
    idx = np.arange(max(lo, 1), hi)
    score = Pr[idx] + 0.5 * Pm[2 * idx] + 0.25 * Pm[3 * idx]          # harmonic-weighted
    j = int(idx[np.argmax(score)])
    for _ in range(2):                                                  # prefer a sub-harmonic if it is also real
        v, jj = _peak(Pr, df, j * df / 2, cfg["tol_bins"])
        if j * df / 2 >= cfg["f0_range"][0] and v > thr:
            j = jj
        else:
            break
    p_r = float(Pr[j])
    f0 = _refine(Ar, j, df)
    ev["radial"] = dict(f0_hz=float(f0), pfr=p_r)

    if p_r < thr:                                                       # nothing rotating-synchronous -> healthy
        b = ev["bearing"]
        worst = max(p_r / thr, (b.get("harm_pfr", 0.0) / cfg["pfr_thr_env"]) if b.get("checked") else 0.0)
        floor_r = float(np.median(_floor(Ar, df, cfg["floor_hw_hz"])[max(lo, 1):hi]))
        ev["detection_limit_radial"] = float(thr * floor_r)             # same units as the input arrays
        # pure noise already reaches ~0.6 of the threshold (max over the search band), so use a steeper mapping:
        # worst = 0.6 -> 0.78, 0.8 -> 0.49, 0.9 -> 0.27, 1.0 -> 0
        healthy_conf = float(np.clip(1.0 - min(worst, 1.0) ** 3, 0.0, 1.0))
        return dict(label="healthy", confidence=healthy_conf, f0_hz=None, evidence=ev,
                    note=f"no radial 1x peak and no impulsive bearing signature; radial 1x peaks above "
                         f"{thr * floor_r:.3g} (input units) would have been detected")

    # ---- 3. imbalance vs misalignment: axial 2x relative to radial 1x
    # noise adds power to a peak bin (E|S+N|^2 = S^2 + N^2): remove it so the ratio is not biased at low SNR
    a_z2, jz = _peak(Az, df, 2 * f0, cfg["tol_bins"])
    fz = _floor(Az, df, cfg["floor_hw_hz"])[jz]
    a_r1 = float(Ar[j])
    fr_ = float(_floor(Ar, df, cfg["floor_hw_hz"])[j])
    z_c = np.sqrt(max(a_z2**2 - 1.44 * fz**2, 0.0))          # Rayleigh bin: E[A^2] = 1.44 * median^2
    r_c = np.sqrt(max(a_r1**2 - 1.19 * fr_**2, 1e-30))       # chi(4) bin:   E[A^2] = 1.19 * median^2
    ratio = z_c / r_c
    ev["axial"] = dict(z_2x=float(a_z2), ratio_z2x_over_r1x=float(ratio))
    label = "misalignment" if ratio > cfg["ratio_thr"] else "imbalance"
    m = min(np.log(p_r / thr), 1.5 * abs(np.log(ratio / cfg["ratio_thr"] + 1e-12)))
    return dict(label=label, confidence=conf(m), f0_hz=float(f0), rpm_est=float(f0 * 60), evidence=ev,
                note=f"radial 1x at {f0:.1f} Hz (PFR {p_r:.1f}), axial 2x / radial 1x = {ratio:.2f}")


# ----------------------------------------------------------------------------- command line
if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="classify one accelerometer CSV (columns: [t,] ax, ay, az)")
    ap.add_argument("csv")
    ap.add_argument("--fs", type=float, required=True, help="sample rate [Hz]")
    ap.add_argument("--cols", type=int, nargs=3, default=None, help="column indices of ax ay az (0-based)")
    a = ap.parse_args()
    d = np.loadtxt(a.csv, delimiter=",", skiprows=1 if not a.csv.endswith(".npy") else 0)
    c = a.cols or ([1, 2, 3] if d.shape[1] >= 4 else [0, 1, 2])
    r = classify(d[:, c[0]], d[:, c[1]], d[:, c[2]], a.fs)
    print(f"{r['label']}  (confidence {r['confidence']:.2f})  -  {r['note']}")
