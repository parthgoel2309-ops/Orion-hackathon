"""
gen_signal.py  -  simulated flight-controller accelerometer data (ax, ay, az) in m/s^2.

    sig = gen_signal("misalignment", seed=3)
    sig["ax"], sig["ay"], sig["az"], sig["fs"], sig["t"]

fault in: "healthy", "imbalance", "misalignment", "bearing_outer", "bearing_inner", "bearing_ball"

Any entry of params.P can be overridden by keyword, e.g.
    gen_signal("imbalance", seed=1, sigma=0.2, U_fault=2e-6, rpm=5400)

Chain (all as in the theory doc):
    forces F(t)  ->  chassis accelerance H(w) (single SDOF, same for every axis)  ->  IMU low-pass + decimation
    ->  + slow rigid-body motion + gravity  ->  + white Gaussian sensor noise  ->  quantisation
"""
import numpy as np
from scipy import signal
from params import P as P_DEFAULT, derived

FAULTS = ["healthy", "imbalance", "misalignment", "bearing_outer", "bearing_inner", "bearing_ball"]
PRE_ROLL = 0.25   # seconds simulated and discarded, so the circular FFT filtering has no wrap-around artefact


def accelerance(f, d, p):
    """H(w) = -w^2 / (-m w^2 + j c w + k)   (Eq. 1)"""
    w = 2 * np.pi * f
    return -(w**2) / (-p["m_eq"] * w**2 + 1j * d["c"] * w + d["k"])


def _bearing_forces(kind, t, fs_sim, d, p, rng, Fx, Fy):
    """Impulse trains, Eqs. 16-19. Impulse of area I is one sample of height I/dt."""
    Om, I = d["Omega"], d["I_impact"]
    dt = 1.0 / fs_sim
    f_fault = {"bearing_outer": d["f_o"], "bearing_inner": d["f_i"], "bearing_ball": 2 * d["f_b"]}[kind]
    Tf = 1.0 / f_fault
    n = np.arange(int(t[-1] / Tf) + 2)
    tn = n * Tf + rng.uniform(0, Tf) + p["jitter"] * Tf * rng.standard_normal(n.size)   # slip jitter eps_n
    beta0 = rng.uniform(0, 2 * np.pi)
    if kind == "bearing_outer":                      # stationary defect: constant direction, uniform amplitude
        beta, amp = np.full(tn.size, beta0), np.full(tn.size, I)
    elif kind == "bearing_inner":                    # defect rotates with shaft, load-zone amplitude modulation
        beta = Om * tn + beta0
        amp = I * (1 + p["load_mod"] * np.cos(beta))
    else:                                            # rolling-element defect: direction rotates at cage frequency
        beta = 2 * np.pi * d["f_c"] * tn + beta0
        amp = np.full(tn.size, I)
    idx = np.rint(tn * fs_sim).astype(int)
    ok = (idx >= 0) & (idx < t.size)
    np.add.at(Fx, idx[ok], (amp * np.cos(beta))[ok] / dt)
    np.add.at(Fy, idx[ok], (amp * np.sin(beta))[ok] / dt)
    # axial component ~ 0 for deep-groove bearings (contact angle ~ 0)


def gen_signal(fault="healthy", seed=0, **overrides):
    if fault not in FAULTS:
        raise ValueError(f"fault must be one of {FAULTS}")
    p = dict(P_DEFAULT)
    p.update(overrides)
    d = derived(p)
    rng = np.random.default_rng(seed)

    fs = p["fs"]
    fs_sim = fs * p["fs_sim_factor"]
    n_keep = int(round(p["T"] * fs_sim))
    n_tot = n_keep + int(round(PRE_ROLL * fs_sim))
    t = np.arange(n_tot) / fs_sim
    Om = d["Omega"]

    phi_b = rng.uniform(0, 2 * np.pi) if p["phi_b"] is None else p["phi_b"]
    phi = rng.uniform(0, 2 * np.pi)          # fault phase (random per window)

    rho, nh = p["harm_decay"], int(p["n_harm"])      # force harmonics decay as rho^(k-1); rho = 0 -> pure sinusoids

    def rotating(amp, Fx, Fy):
        """Rotating radial force at orders 1..nh (order 1 is the doc's equation; higher orders are the realism add-on)."""
        for k in range(1, nh + 1):
            a = amp * rho ** (k - 1)
            if a == 0:
                break
            ph = phi if k == 1 else rng.uniform(0, 2 * np.pi)
            Fx += a * np.sin(k * Om * t + ph)
            Fy += a * np.cos(k * Om * t + ph)

    def axial(amp, Fz, ph1):
        """Axial force at 2*Omega * j  (j = 1..nh): 2Omega, 4Omega, 6Omega ..."""
        for j in range(1, nh + 1):
            a = amp * rho ** (j - 1)
            if a == 0:
                break
            ph = ph1 if j == 1 else rng.uniform(0, 2 * np.pi)
            Fz += a * np.sin(2 * j * Om * t + ph)

    Fx = np.zeros(n_tot)
    Fy = np.zeros(n_tot)
    Fz = np.zeros(n_tot)
    axial(d["F_bpf"], Fz, phi_b)                             # healthy blade-pass baseline (Eq. 3) + its harmonics, in EVERY class

    if fault == "imbalance":                                 # Eqs. 4-5, Fz = 0
        rotating(d["F_imb"], Fx, Fy)
    elif fault == "misalignment":                            # Eqs. 9-11, phi2 = phi_b
        rotating(d["F1"], Fx, Fy)
        axial(d["F2"], Fz, phi_b)
    elif fault.startswith("bearing"):
        _bearing_forces(fault, t, fs_sim, d, p, rng, Fx, Fy)

    # ---- chassis (LTI): a_struct = IFFT( H(w) * FFT(F) ), same H on every axis (hx = hy, symmetric chassis)
    H = accelerance(np.fft.rfftfreq(n_tot, 1 / fs_sim), d, p)
    a_struct = [np.fft.irfft(H * np.fft.rfft(F), n=n_tot) for F in (Fx, Fy, Fz)]

    # ---- IMU front end: causal anti-alias low-pass, then decimate to the IMU rate, drop pre-roll
    sos = signal.butter(4, p["imu_lpf_hz"], fs=fs_sim, output="sos")
    step = p["fs_sim_factor"]
    a_imu = [signal.sosfilt(sos, a)[-n_keep:][::step] for a in a_struct]
    n = a_imu[0].size
    t_imu = np.arange(n) / fs

    # ---- slow rigid-body motion + gravity (a real IMU measures specific force, ~ +g on z in hover)
    def slow():
        f = rng.uniform(0.3, 5.0, 3)
        ph = rng.uniform(0, 2 * np.pi, 3)
        return p["rigid_amp"] / np.sqrt(3) * sum(np.sin(2 * np.pi * fi * t_imu + pi) for fi, pi in zip(f, ph))

    tilt = np.deg2rad(rng.uniform(-1, 1, 2))
    ax = a_imu[0] + slow() + p["g"] * np.sin(tilt[0])
    ay = a_imu[1] + slow() + p["g"] * np.sin(tilt[1])
    az = a_imu[2] + slow() + p["g"]

    # ---- sensor noise + quantisation
    out = []
    for a in (ax, ay, az):
        a = a + p["sigma"] * rng.standard_normal(n)
        if p["lsb"] > 0:
            a = np.round(a / p["lsb"]) * p["lsb"]
        out.append(a)

    return dict(t=t_imu, ax=out[0], ay=out[1], az=out[2], fs=fs, fault=fault, seed=seed,
                f0=d["f0"], params=p, derived=d)


def save_csv(sig, path):
    """time, ax, ay, az  [s, m/s^2] - same layout as a typical logged IMU file."""
    arr = np.column_stack([sig["t"], sig["ax"], sig["ay"], sig["az"]])
    np.savetxt(path, arr, delimiter=",", header="t_s,ax_mps2,ay_mps2,az_mps2", comments="", fmt="%.6f")


if __name__ == "__main__":
    s = gen_signal("misalignment", seed=0)
    print({k: (v.shape if hasattr(v, "shape") else v) for k, v in s.items() if k not in ("params", "derived")})
    print("mean ax, ay, az:", s["ax"].mean(), s["ay"].mean(), s["az"].mean())
