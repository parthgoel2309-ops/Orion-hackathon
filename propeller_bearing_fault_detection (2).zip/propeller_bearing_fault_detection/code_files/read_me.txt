How to use the code files : 
1. the files "params.py", "gen_signal.py" and "plot_spectra.py" are related.
2. plot_spectra.py generates the simulated accelerometer data and saves as a csv file, also generates the graphs.
3. run_experiments.py runs the code multiple times with simulated data, with different noise levels and produces a report file.
4. run the plot_spectra.py to plot the signals.
5. run rum_experiments.py to see the results on simulated data across various noise floors. 