"""
classify_file.py  -  run classify() on a recorded accelerometer file, window by window.

    python classify_file.py data.csv --fs 1000 --cols 1 2 3
    python classify_file.py data.csv --time-col 0 --cols 1 2 3          # fs taken from the time column
    python classify_file.py data.npy --fs 8000 --cols 0 1 2 --win 1.0

--cols  : column numbers (0-based) of the two RADIAL axes then the AXIAL axis:  x y z
          (x, y in the rotor plane, z along the thrust axis - the classifier assumes this; if the dataset's axes
           are different, reorder them here)
--win   : window length in seconds (default 1.0 s; use the same length the classifier was developed on)
--step  : hop between windows in seconds (default = --win, i.e. no overlap)

Prints one line per window and a summary (count per label + majority label).
Units do not matter (g, m/s^2 or raw counts), but the sample rate does:
  * fs < 3000 Hz  -> the bearing (envelope) branch is skipped automatically;
  * fs < ~1000 Hz -> only the radial 1x / axial 2x logic is meaningful.
"""
import argparse
from collections import Counter
import numpy as np
from classify import classify


def load(path):
    if path.endswith(".npy"):
        return np.load(path)
    for skip in (0, 1):
        for delim in (",", None):                      # comma-separated, then whitespace
            try:
                return np.loadtxt(path, delimiter=delim, skiprows=skip)
            except ValueError:
                continue
    raise ValueError("could not read the file as numeric CSV / whitespace text / .npy")


def main():
    ap = argparse.ArgumentParser(description="classify a recorded accelerometer file window by window")
    ap.add_argument("path")
    ap.add_argument("--fs", type=float, default=None, help="sample rate [Hz]")
    ap.add_argument("--time-col", type=int, default=None, help="time column (seconds): fs = 1/median(dt)")
    ap.add_argument("--cols", type=int, nargs=3, default=[1, 2, 3], help="columns of x y z (default 1 2 3)")
    ap.add_argument("--win", type=float, default=1.0, help="window length [s]")
    ap.add_argument("--step", type=float, default=None, help="hop [s] (default = win)")
    a = ap.parse_args()

    d = load(a.path)
    if d.ndim != 2:
        raise ValueError(f"expected a 2-D table, got shape {d.shape}")
    fs = a.fs
    if fs is None:
        if a.time_col is None:
            raise SystemExit("give --fs or --time-col")
        fs = 1.0 / float(np.median(np.diff(d[:, a.time_col])))
    x, y, z = (d[:, c] for c in a.cols)
    n = int(round(a.win * fs))
    hop = int(round((a.step or a.win) * fs))
    print(f"{len(x)} samples, fs = {fs:.1f} Hz, window = {a.win} s ({n} samples), hop = {hop / fs:.2f} s")
    if len(x) < n:
        raise SystemExit("file is shorter than one window")

    labels = []
    for k, s in enumerate(range(0, len(x) - n + 1, hop)):
        r = classify(x[s:s + n], y[s:s + n], z[s:s + n], fs)
        labels.append(r["label"])
        print(f"t = {s / fs:7.2f} s   {r['label']:13s} conf {r['confidence']:.2f}   {r['note']}")
    c = Counter(labels)
    print("\nsummary:", dict(c), "-> majority:", c.most_common(1)[0][0])


if __name__ == "__main__":
    main()
