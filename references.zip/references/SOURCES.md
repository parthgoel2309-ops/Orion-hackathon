# Sources

## Acceleration dataset

The supplied workbooks correspond to the dataset described in:

[Multiaxial vibration data for blade fault diagnosis in multirotor unmanned aerial vehicles](https://www.nature.com/articles/s41597-025-05692-4), DOI: 10.1038/s41597-025-05692-4.

The project retains the supplied condition labels: healthy, damaged top-right, damaged bottom-right, unbalanced top-right and unbalanced bottom-right. File checksums and original supplied paths are in data/raw/source_manifest.json. Full workbooks are not committed; the existing analyses use the included measurement extracts where possible.

## Other supplied references

The local workspace contains papers named massimbalance_paper.pdf, prop_imb.pdf and uav_bearing (1).pdf. Their local copies and earlier review notes are kept outside Git under references/papers and references/paper_notes. These filenames alone do not establish redistribution rights or validate the signal models.

The repository does not claim ownership of source datasets or publications. Check the source terms before redistributing additional data or reference documents.
