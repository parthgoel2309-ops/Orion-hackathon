# References

Source links and attribution notes are in SOURCES.md. In the original local workspace, `papers/` contains unchanged copies of the four supplied papers and `paper_notes/` contains text extracts and page previews. These local copies are excluded from Git. Page previews are reference material, not graphs generated from the vibration data. External paper originals remain in place.
