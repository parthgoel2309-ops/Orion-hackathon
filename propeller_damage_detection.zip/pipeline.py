"""Detect possible propeller blade damage from Excel acceleration data.

The method, in order:
    Excel time + X/Y -> 10-second windows -> averaged FFT power spectra
    -> spectral features (36 by default) -> healthy scaling -> logistic regression.

Start with train_pipeline() and predict_file() below. They show the complete
workflow. The later sections contain signal processing, model maths, plots,
and file checks, so those details do not interrupt the main steps.

Train:          python pipeline.py train
Train flights:  python pipeline.py train --config input_dronepropa.json
Check a file:   python pipeline.py predict
Run checks:     python pipeline.py self-test
"""
from __future__ import annotations

# %% 1. Settings
import argparse
import copy
import hashlib
import json
from pathlib import Path
import platform
import sys

import numpy as np
import scipy
from scipy import optimize, signal, special, stats
from openpyxl import load_workbook

HERE = Path(__file__).resolve().parent
AXES = "xy"
LABELS = {0: "Undamaged", 1: "Damaged"}
MODEL_VERSION = 2
TRAINING_IMAGES = ["confusion_matrix.png", "healthy_x.png", "healthy_y.png",
    "damaged_x.png", "damaged_y.png", "noise_test.png"]

# Advanced defaults stay here so input.json contains only everyday settings.
PROCESSING = {
    "axes": ["x", "y"], "feature_method": "dominant_peaks",
    "window_seconds": 10, "fft_samples": 250, "overlap_fraction": .5,
    "gap_factor": 1.5, "max_relative_jitter": .01,
    "min_sample_coverage": .8, "min_frame_coverage": .6,
    "peak_features": {"count": 3, "min_separation_bins": 3,
        "min_prominence_fraction": .01, "noise_floor_multiplier": 3.,
        "max_sampling_rate_change_fraction": .05}}
TRAINING = {"train_fraction": .6, "validation_fraction": .2,
    "guard_windows": 1, "l2_strength": .1, "normalisation_std_floor": 1e-12,
    "normalisation_relative_floor": 1e-6, "persistence_windows": 2, "seed": 42}
NOISE = {"enabled": True, "snr_db": [30, 20, 10, 0], "repeats": 3}
EXCEL_FORMAT = {"sheet": "Sheet1", "header_row": 1,
    "columns": {"time": "Time (s)", "x": "X Acceleration", "y": "Y Acceleration"},
    "time_unit": "s", "acceleration_unit": "m/s^2"}


class WindowRejected(ValueError):
    """A complete window has insufficient usable measurements."""


# %% 2. Main workflows - start reading here

def train_pipeline(config, verbose=False):
    """Train once, select a validation cutoff, then evaluate and save results."""
    output = prepare_training_output(config)

    # 1. Read the Excel files and calculate features for every valid window.
    records = load_recordings(config)
    windows, rejected, names = prepare_windows(config, records)

    # 2. Keep training, validation and test windows separate.
    partitions = {split: [item for item in windows if item["split"] == split]
        for split in ["train", "validation", "test"]}
    for split, selected in partitions.items():
        if {item["label"] for item in selected} != {0, 1}:
            raise ValueError(f"{split} needs healthy and damaged windows after quality checks.")
    features = np.stack([item["features"] for item in partitions["train"]])
    labels = np.asarray([item["label"] for item in partitions["train"]], dtype=int)

    # 3. Fit feature scaling using healthy TRAINING windows only.
    reference = healthy_reference(features, labels, config["training"])

    # 4. Learn logistic regression from scaled training features and known labels.
    scaled_features = normalise(features, reference)
    classifier = fit_classifier(scaled_features, labels, config["training"]["l2_strength"])
    model = build_model(config, records, partitions["train"], names, reference, classifier)
    for identity, record in records.items():
        check_sampling_support(record["fs"], model["sampling_support"], identity)

    # 5. Choose the cutoff on validation windows; the classifier stays fixed.
    validation = partitions["validation"]
    scores = damage_scores(np.stack([item["features"] for item in validation]), model)
    model["threshold"] = choose_threshold([item["label"] for item in validation], scores, verbose)

    # 6. Evaluate the fitted model, including untouched test windows.
    apply_predictions(windows, model)
    summaries = {split: metrics([item["label"] for item in selected],
        [item["damage_score"] for item in selected], model["threshold"]) for split, selected in partitions.items()}
    chronological = any(item["split"] == "chronological" for item in config["recordings"])
    report = {"validation_design": "reserved sections of the same recordings" if chronological else "whole-flight holdout",
        "split_counts": {split: sum(item["split"] == split for item in windows)
            for split in ["train", "validation", "test", "guard"]},
        "rejected_count": len(rejected), "metrics": summaries, "noise_test": None}
    if config["noise_test"]["enabled"]:
        print("Checking noise sensitivity ...", flush=True)
        report["noise_test"] = noise_experiment(windows, records, model, config["noise_test"])

    # 7. Save the model, brief summary and requested graphs.
    make_training_figures(windows, records, model, report, output)
    save_json(output / "model.json", model)
    summary = training_summary(model, report)
    (output / "training_summary.txt").write_text(summary, encoding="utf-8")
    result = summaries["test"]
    correct = sum(np.diag(result["confusion_matrix_rows_true_columns_predicted"]))
    print(f"\nTraining complete - combined X/Y\n"
        f"Test: {correct}/{result['windows']} windows correct ({result['accuracy']:.1%})\n"
        f"Damage recall: {result['damage_recall']:.1%} | Healthy false alarms: {result['healthy_false_positive_rate']:.1%}\n"
        f"Decision cutoff: {model['threshold']:.6f}\n"
        f"Evaluation: {report['validation_design']}.\n"
        f"Saved in {output.name}/: model.json, training_summary.txt and separate PNG images", flush=True)
    return model, report, windows


def predict_file(path, model_path, output):
    """Assess a new Excel file with a saved model; do not train or retune it."""
    # 1. Load the fitted model and the new recording.
    model = load_model(model_path)
    path = Path(path).resolve()
    record = read_excel(path, model["excel_format"], model["processing"], path.stem)
    check_sampling_support(record["fs"], model["sampling_support"], path.stem)

    # 2. Calculate exactly the same features used during training.
    config = {"processing": model["processing"], "training": {}, "recordings": [
        {"id": path.stem, "flight_id": path.stem, "label": None, "split": "prediction"}]}
    windows, rejected, names = prepare_windows(config, {path.stem: record})
    if windows and names != model["feature_names"]:
        raise ValueError("Input features do not match the saved model.")

    # 3. Score each window, then apply the consecutive-window alarm rule.
    apply_predictions(windows, model)
    assessment = recording_assessment(windows, rejected, record["audit"], model["processing"], model["persistence_windows"])

    # 4. Show and save one short recording result.
    damaged = sum(item["prediction"] == "Damaged" for item in windows)
    reused = record["audit"]["sha256"] in model["training_recording_hashes"]
    lines = [f"File: {path.name}", f"Result: {assessment['result']}", f"Reason: {assessment['reason']}",
        f"Windows: {len(windows) - damaged} healthy | {damaged} damaged | {len(rejected)} rejected",
        f"Unanalysed final partial window: {assessment['unanalysed_tail_seconds']:.3f} seconds"]
    if assessment["first_alarm_confirmed_at_s"] is not None:
        lines.append(f"First confirmed alarm: {assessment['first_alarm_confirmed_at_s']:g} seconds")
    if assessment["flagged_intervals"]:
        lines.append("Flagged intervals: " + "; ".join(f"{item['start_s']:g}-{item['end_s']:g} s"
            + (" (sustained)" if item["sustained"] else " (review)") for item in assessment["flagged_intervals"]))
    if reused:
        lines.append("This file was used in training; this is a consistency check.")
    lines.append(f"Saved cutoff: {model['threshold']:.6f}; model remains fixed.")
    summary = "\n".join(lines) + "\n"
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    result_path = output / "prediction.txt"
    if result_path == path or result_path == Path(model_path).resolve():
        raise ValueError("Prediction output cannot overwrite the input or model.")
    result_path.write_text(summary, encoding="utf-8")
    print("\n" + summary + f"Saved: {result_path}", flush=True)
    return windows, assessment


# %% 3. Acceleration windows, FFT/PSD and spectral features

def read_excel(path, fmt, proc, identity):
    """Read numeric [time, X, Y] rows and check the recording's sampling."""
    path = Path(path).resolve()
    before = path.stat()
    book = load_workbook(path, read_only=True, data_only=True)
    try:
        if fmt["sheet"] not in book.sheetnames:
            raise ValueError(f"{path.name}: sheet {fmt['sheet']!r} was not found.")
        sheet = book[fmt["sheet"]]
        header = next(sheet.iter_rows(min_row=fmt["header_row"], max_row=fmt["header_row"], values_only=True))
        header = [str(value).strip() if value is not None else "" for value in header]
        wanted = [fmt["columns"][key] for key in ["time", *active_axes(proc)]]
        if any(header.count(name) != 1 for name in wanted):
            raise ValueError(f"{path.name}: required unique columns {wanted}; found {header}.")
        indices = [header.index(name) for name in wanted]
        values, excel_rows = [], []
        for number, row in enumerate(sheet.iter_rows(min_row=fmt["header_row"] + 1,
                max_col=max(indices) + 1, values_only=True), fmt["header_row"] + 1):
            selected = [row[index] for index in indices]
            if all(value is None for value in selected):
                continue
            try:
                if any(isinstance(value, bool) for value in selected):
                    raise ValueError("boolean measurement")
                numeric = [float(value) for value in selected]
                if not np.isfinite(numeric).all():
                    raise ValueError("non-finite measurement")
            except (TypeError, ValueError) as error:
                raise ValueError(f"{path.name}: invalid numeric data in Excel row {number}.") from error
            values.append(numeric)
            excel_rows.append(number)
    finally:
        book.close()
    data = np.asarray(values, dtype=float)
    if len(data) < proc["fft_samples"]:
        raise ValueError(f"{path.name}: too few samples.")
    dt = np.diff(data[:, 0])
    if np.any(dt <= 0):
        raise ValueError(f"{path.name}: timestamps must increase strictly; duplicates/resets are rejected.")
    regular = dt <= proc["gap_factor"] * np.median(dt)
    if not regular.any():
        raise ValueError(f"{path.name}: no regular sampling intervals.")
    mean_dt = float(dt[regular].mean())
    jitter = float(np.max(np.abs(dt[regular] / mean_dt - 1)))
    if jitter > proc["max_relative_jitter"]:
        raise ValueError(f"{path.name}: within-block timing jitter {jitter:.2%} exceeds the configured limit.")
    fs = 1 / mean_dt
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError(f"{path.name}: file changed while being read.")
    data[:, 0] -= data[0, 0]
    audit = {"id": identity, "file": path.name, "sha256": file_hash(path), "samples": len(data),
        "duration_s": float(data[-1, 0]), "sampling_rate_hz": fs, "nyquist_hz": fs / 2,
        "fft_bin_spacing_hz": fs / proc["fft_samples"], "timestamp_gaps": int((~regular).sum()),
        "max_relative_regular_jitter": jitter, "first_excel_row": int(excel_rows[0]),
        "last_excel_row": int(excel_rows[-1]), "sheet": fmt["sheet"]}
    return {"data": data, "source_rows": np.asarray(excel_rows), "fs": fs, "audit": audit}


def select_window(record, start, duration):
    """Select timestamps from start up to, but not including, start + duration."""
    times = record["data"][:, 0]
    left, right = np.searchsorted(times, [start, start + duration], side="left")
    return record["data"][left:right], record["source_rows"][left:right]


def window_psd(data, rows, fs, proc):
    """Average the valid Hann-frame PSDs inside one decision window.

    Returns frequency bins, a two-column X/Y PSD, and window coverage details.
    """
    size = int(proc["fft_samples"])
    hop = max(1, int(round(size * (1 - proc["overlap_fraction"]))))
    coverage = len(data) / (fs * proc["window_seconds"])
    if len(data) < size or coverage < proc["min_sample_coverage"]:
        raise WindowRejected("Insufficient sample coverage.")
    # Missing Excel rows also interrupt a run, even if timestamps hide the gap.
    breaks = (np.diff(data[:, 0]) > proc["gap_factor"] / fs) | (np.diff(rows) != 1)
    bounds = np.r_[0, np.flatnonzero(breaks) + 1, len(data)]
    spectra, used = [], np.zeros(len(data), dtype=bool)
    for left, right in zip(bounds[:-1], bounds[1:]):
        for offset in range(int(left), int(right) - size + 1, hop):
            frequency, density = signal.periodogram(data[offset:offset + size, 1:], fs=fs,
                window="hann", detrend="constant", scaling="density", axis=0)
            spectra.append(density)
            used[offset:offset + size] = True
    frame_coverage = int(used.sum()) / (fs * proc["window_seconds"])
    if not spectra or frame_coverage < proc["min_frame_coverage"]:
        raise WindowRejected("Insufficient coverage by uninterrupted FFT frames.")
    # Each frame has the same weight, as in Welch's mean estimate.
    density = np.mean(spectra, axis=0)
    if not np.isfinite(density).all():
        raise WindowRejected("Non-finite spectral density.")
    return frequency, density, {"samples": len(data), "spectral_frames": len(spectra),
        "sample_coverage": float(coverage), "frame_coverage": float(frame_coverage)}


def band_power(frequency, density, low, high):
    """Integrate PSD between two frequencies, interpolating the endpoints."""
    inside = (frequency > low) & (frequency < high)
    f = np.r_[low, frequency[inside], high]
    p = np.r_[np.interp(low, frequency, density), density[inside], np.interp(high, frequency, density)]
    integral = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
    return float(integral(p, f))


def dominant_peak_features(frequency, density, settings, axes):
    """Build features from the full positive-frequency PSD (18/axis by default).

    Each axis: total power, entropy, flatness, then height/prominence/width/
    power/power fraction for its selected peaks (three by default). Peak centres
    are returned for graphs only; they are not classifier inputs.
    """
    frequency, density = np.asarray(frequency), np.asarray(density)
    if (frequency.ndim != 1 or len(frequency) < 4 or density.shape != (len(frequency), len(axes))
            or not np.isfinite(frequency).all() or not np.isfinite(density).all()
            or np.any(density < 0) or frequency[0] != 0 or np.any(np.diff(frequency) <= 0)):
        raise ValueError("Peak extraction requires a finite, nonnegative one-sided PSD starting at DC.")
    spacing = float(frequency[1] - frequency[0])
    if not np.allclose(np.diff(frequency), spacing, rtol=1e-6, atol=1e-10):
        raise ValueError("Peak extraction requires uniformly spaced FFT bins.")
    values, names, diagnostics = [], [], {}
    for column, axis in enumerate(axes):
        p = density[:, column]
        positive = p[1:]  # DC is excluded; all available positive frequencies remain.
        total = float(positive.sum() * spacing)
        if total <= np.finfo(float).tiny:
            raise WindowRejected(f"No measurable positive-frequency vibration on {axis.upper()}.")
        probabilities = positive * spacing / total
        nonzero = probabilities > 0
        entropy = float(-np.sum(probabilities[nonzero] * np.log(probabilities[nonzero])) / np.log(len(positive)))
        flatness = float(np.exp(np.mean(np.log(np.maximum(positive, np.finfo(float).tiny)))) / positive.mean())
        floor = float(np.median(positive))
        prominence = max(float(positive.max()) * settings["min_prominence_fraction"],
            floor * settings["noise_floor_multiplier"])
        candidates, properties = signal.find_peaks(p, prominence=prominence, width=(None, None))
        # Strongest first; nearby lobes cannot occupy multiple peak ranks.
        selected = []
        for index in sorted(range(len(candidates)), key=lambda i: (-p[candidates[i]], candidates[i])):
            if all(abs(int(candidates[index]) - int(candidates[other])) >= settings["min_separation_bins"] for other in selected):
                selected.append(index)
                if len(selected) == settings["count"]:
                    break
        current = {"median_psd": floor, "minimum_prominence": prominence,
            "candidate_peaks": len(candidates), "selected_peaks": len(selected),
            "maximum_at_nyquist": bool(np.argmax(positive) == len(positive) - 1), "peaks": []}
        for kind, value in [("total_power", total), ("spectral_entropy", entropy), ("spectral_flatness", flatness)]:
            names.append(f"{axis}_{kind}")
            values.append(value)
        for rank in range(settings["count"]):
            peak = {"rank": rank + 1, "present": rank < len(selected), "frequency_hz": None,
                "height": 0., "prominence": 0., "width_hz": 0., "power": 0.,
                "power_fraction": 0., "left_hz": None, "right_hz": None}
            if peak["present"]:
                index = selected[rank]
                centre = int(candidates[index])
                left = max(float(frequency[1]), float(np.interp(properties["left_ips"][index], np.arange(len(frequency)), frequency)))
                right = float(np.interp(properties["right_ips"][index], np.arange(len(frequency)), frequency))
                power = band_power(frequency, p, left, right)
                peak.update(frequency_hz=float(frequency[centre]), height=float(p[centre]),
                    prominence=float(properties["prominences"][index]), width_hz=right - left,
                    power=power, power_fraction=power / total, left_hz=left, right_hz=right)
            current["peaks"].append(peak)
            for kind in ["height", "prominence", "width_hz", "power", "power_fraction"]:
                names.append(f"{axis}_peak{rank + 1}_{kind}")
                values.append(peak[kind])
        diagnostics[axis] = current
    return np.asarray(values), names, diagnostics


def extract_features(frequency, density, processing):
    return dominant_peak_features(frequency, density, processing["peak_features"], AXES)


def prepare_windows(config, records):
    """Turn recordings into accepted 10-second windows with spectral features."""
    windows, rejected, feature_names = [], [], None
    proc = config["processing"]
    for item in config["recordings"]:
        record = records[item["id"]]
        count = int(np.floor((record["data"][-1, 0] + 1 / record["fs"]) / proc["window_seconds"]))
        record["audit"]["candidate_windows"] = count
        record["audit"]["discarded_tail_seconds"] = max(0., float(record["data"][-1, 0] - count * proc["window_seconds"]))
        for index in range(count):
            start = index * proc["window_seconds"]
            meta = {"recording_id": item["id"], "flight_id": item["flight_id"], "label": item["label"],
                "window_index": index, "start_s": start, "end_s": start + proc["window_seconds"],
                "split": split_for_window(index, count, item, config["training"])}
            data, rows = select_window(record, start, proc["window_seconds"])
            try:
                f, p, quality = window_psd(data, rows, record["fs"], proc)
                features, names, peaks = extract_features(f, p, proc)
            except WindowRejected as error:
                rejected.append({**meta, "reason": str(error)})
                continue
            if feature_names is not None and names != feature_names:
                raise ValueError("Feature definitions changed between recordings.")
            feature_names = names
            windows.append({**meta, **quality, "features": features, "frequency": f, "psd": p, "peak_diagnostics": peaks})
    return windows, rejected, feature_names


def example_fft_frame(data, rows, fs, processing):
    """Choose the middle of the valid FFT frames used by the PSD calculation."""
    size = int(processing["fft_samples"])
    hop = max(1, int(round(size * (1 - processing["overlap_fraction"]))))
    breaks = (np.diff(data[:, 0]) > processing["gap_factor"] / fs) | (np.diff(rows) != 1)
    bounds = np.r_[0, np.flatnonzero(breaks) + 1, len(data)]
    starts = [offset for left, right in zip(bounds[:-1], bounds[1:])
        for offset in range(int(left), int(right) - size + 1, hop)]
    if not starts:
        raise ValueError("The example window has no uninterrupted FFT frame.")
    offset = starts[len(starts) // 2]
    return offset, offset + size, bounds


# %% 4. Healthy reference, logistic regression and decisions

def healthy_reference(features, labels, train, drop_constant=True):
    """Find one healthy training mean/std per feature (columns of features)."""
    healthy = features[labels == 0]
    if len(healthy) < 2:
        raise ValueError("At least two healthy training windows are required.")
    mean = healthy.mean(axis=0)
    std = healthy.std(axis=0, ddof=1)
    floor = np.maximum(train["normalisation_std_floor"], np.abs(mean) * train["normalisation_relative_floor"])
    scale = np.maximum(std, floor)
    reference = {"mean": mean.tolist(), "std": std.tolist(), "scale": scale.tolist(),
        "floored_feature_count": int((std < floor).sum()), "healthy_training_windows": len(healthy), "ddof": 1}
    if drop_constant:
        # A missing rank in every healthy window has no estimable healthy variance.
        # Ignore it rather than turn its first appearance into an enormous z score.
        reference["active_features"] = (std > floor).tolist()
        reference["ignored_constant_feature_count"] = int((std <= floor).sum())
    return reference


def normalise(features, reference):
    """Scale feature columns using the saved reference; do not rescale the waveform."""
    result = (np.asarray(features) - np.asarray(reference["mean"])) / np.asarray(reference["scale"])
    if "active_features" in reference:
        result = np.where(reference["active_features"], result, 0.)
    if not np.isfinite(result).all():
        raise ValueError("Feature normalisation produced non-finite values.")
    return result


def fit_classifier(features, labels, strength):
    """Learn the logistic coefficients from already-scaled training features.

    Logistic regression learns a weighted sum of the features and an
    intercept. SciPy handles the optimisation; prediction reuses those weights.
    """
    counts = np.bincount(labels, minlength=2)
    if np.any(counts == 0):
        raise ValueError("Training must contain both undamaged and damaged windows.")

    # Give healthy and damaged windows equal total weight despite unequal counts.
    weights = len(labels) / (2 * counts[labels])
    initial_parameters = np.zeros(features.shape[1] + 1)
    fitted = optimize.minimize(
        logistic_objective,
        initial_parameters,
        args=(features, labels, weights, strength),
        jac=True,
        method="L-BFGS-B",
        options={"maxiter": 2000, "ftol": 1e-12, "gtol": 1e-8},
    )
    if not fitted.success or not np.isfinite(fitted.x).all():
        raise ValueError(f"Classifier optimisation failed: {fitted.message}")
    return {"coefficients": fitted.x[:-1].tolist(), "intercept": float(fitted.x[-1]),
        "l2_strength": strength, "loss": "class-balanced weighted mean logistic loss + lambda/2 * sum(w^2)",
        "iterations": int(fitted.nit), "objective": float(fitted.fun), "optimisation_success": True}


def damage_scores(features, model):
    """Return one damage score per window using the frozen model."""
    scaled = normalise(features, model["healthy_reference"])
    coefficients = np.asarray(model["classifier"]["coefficients"])
    intercept = model["classifier"]["intercept"]
    logits = scaled @ coefficients + intercept
    return special.expit(logits)


def choose_threshold(labels, scores, verbose=False):
    """Choose a cutoff using validation scores only; fitting is already complete."""
    labels, scores = np.asarray(labels, dtype=int), np.asarray(scores, dtype=float)
    if set(labels) != {0, 1} or scores.shape != labels.shape or not np.isfinite(scores).all():
        raise ValueError("Threshold selection needs both validation labels and finite scores.")
    # Each midpoint tests a different separation of the validation scores.
    unique = np.unique(scores)
    midpoints = (unique[:-1] + unique[1:]) / 2
    candidates = np.unique(np.r_[0., .5, 1., midpoints])
    trial_cutoffs = sorted(candidates, key=lambda value: (abs(value - .5), value))
    best, best_quality = .5, None
    if verbose:
        print("\nTrial   Tried cutoff   Validation balanced accuracy   Best cutoff", flush=True)
    for iteration, cutoff in enumerate(trial_cutoffs, 1):
        result = metrics(labels, scores, cutoff)
        # Prefer balanced accuracy, then closeness to 0.5, recall, lower cutoff.
        quality = (result["balanced_accuracy"], -abs(cutoff - .5), result["damage_recall"], -cutoff)
        if best_quality is None or quality > best_quality:
            best, best_quality = float(cutoff), quality
        if verbose:
            print(f"{iteration:5d}   {cutoff:12.8g}   {result['balanced_accuracy']:26.1%}   {best:.8g}", flush=True)
    return best


def apply_predictions(windows, model):
    """Score windows and flag runs of consecutive positive decisions."""
    if not windows:
        return
    features = np.stack([item["features"] for item in windows])
    scores = damage_scores(features, model)
    previous_recording = None
    previous_split = None
    previous_index = None
    streak = 0
    for item, score in zip(windows, scores):
        consecutive = (
            item["recording_id"] == previous_recording
            and item["split"] == previous_split
            and previous_index is not None
            and item["window_index"] == previous_index + 1
        )
        if not consecutive:
            streak = 0
        positive = bool(score >= model["threshold"])
        streak = streak + 1 if positive else 0
        item.update(damage_score=float(score), prediction=LABELS[int(positive)],
            sustained_alarm=bool(streak >= model["persistence_windows"]))
        previous_recording = item["recording_id"]
        previous_split = item["split"]
        previous_index = item["window_index"]


def recording_assessment(windows, rejected, audit, processing, persistence):
    """Summarise a recording using the existing sustained-alarm rule, not score averaging."""
    intervals, current, longest, run, previous = [], None, 0, 0, None
    for item in windows:
        consecutive = previous is not None and item["window_index"] == previous["window_index"] + 1
        run = run + 1 if consecutive else 1
        longest = max(longest, run)
        if item["prediction"] == "Damaged":
            if current is None or not consecutive:
                current = {"start_s": item["start_s"], "end_s": item["end_s"],
                    "positive_windows": 0, "sustained": False, "alarm_confirmed_at_s": None}
                intervals.append(current)
            current["end_s"] = item["end_s"]
            current["positive_windows"] += 1
            if item["sustained_alarm"]:
                current["sustained"] = True
                if current["alarm_confirmed_at_s"] is None:
                    current["alarm_confirmed_at_s"] = item["end_s"]
        else:
            current = None
        previous = item
    alarms = [item for item in intervals if item["sustained"]]
    if alarms:
        status, label = "possible_blade_damage", "POSSIBLE BLADE DAMAGE"
        reason = f"At least {persistence} consecutive windows exceeded the saved damage cutoff."
    elif intervals:
        status, label = "inconclusive", "INCONCLUSIVE - REVIEW REQUIRED"
        reason = "Isolated damage flags occurred without enough consecutive positive windows to confirm an alarm."
    elif longest < persistence:
        status, label = "insufficient_data", "INSUFFICIENT DATA"
        reason = f"Need at least {persistence} consecutive accepted windows ({persistence * processing['window_seconds']:g} seconds) for this recording assessment."
    elif rejected:
        status, label = "inconclusive", "INCONCLUSIVE - INCOMPLETE COVERAGE"
        reason = "No damage flags in accepted windows, but some complete windows failed data-quality checks."
    else:
        status, label = "no_blade_damage_detected", "NO BLADE DAMAGE DETECTED"
        reason = "No accepted complete window exceeded the saved damage cutoff."
    return {"status": status, "result": label, "reason": reason,
        "rule": "Any sustained alarm flags the recording; isolated positives or incomplete coverage require review. Scores are not averaged into a recording confidence.",
        "accepted_windows": len(windows), "rejected_windows": len(rejected),
        "analysed_decision_seconds": len(windows) * processing["window_seconds"],
        "unanalysed_tail_seconds": audit["discarded_tail_seconds"],
        "longest_consecutive_accepted_windows": longest,
        "first_alarm_confirmed_at_s": alarms[0]["alarm_confirmed_at_s"] if alarms else None,
        "flagged_intervals": intervals,
        "scope": "Propeller blade-damage assessment in analysed windows; not an assessment of every UAV component or flightworthiness. Flagged intervals are decision windows, not exact fault onset times."}


def metrics(labels, scores, threshold):
    """Compare window scores with known labels at a fixed cutoff."""
    labels = np.asarray(labels, dtype=int)
    predicted = np.asarray(scores) >= threshold
    tn = int(((labels == 0) & ~predicted).sum())
    fp = int(((labels == 0) & predicted).sum())
    fn = int(((labels == 1) & ~predicted).sum())
    tp = int(((labels == 1) & predicted).sum())
    recall = tp / (tp + fn) if tp + fn else None
    specificity = tn / (tn + fp) if tn + fp else None
    precision = tp / (tp + fp) if tp + fp else None
    auc = None
    if tp + fn and tn + fp:
        ranks = stats.rankdata(scores)
        positives, negatives = tp + fn, tn + fp
        auc = float((ranks[labels == 1].sum() - positives * (positives + 1) / 2) / (positives * negatives))
    return {"windows": len(labels), "confusion_matrix_rows_true_columns_predicted": [[tn, fp], [fn, tp]],
        "accuracy": (tn + tp) / len(labels), "damage_recall": recall, "damage_precision": precision,
        "healthy_false_positive_rate": fp / (tn + fp) if tn + fp else None,
        "balanced_accuracy": (recall + specificity) / 2 if recall is not None and specificity is not None else None,
        "roc_auc": auc}


def logistic_objective(parameters, features, labels, weights, strength):
    """Logistic loss and derivatives used internally by SciPy's fitting routine.

    features: one row per training window, one column per spectral feature.
    parameters: one coefficient per feature, followed by the intercept.
    """
    coefficients = parameters[:-1]
    intercept = parameters[-1]
    logits = features @ coefficients + intercept

    # How far the current predictions are from the known training labels.
    sample_loss = np.logaddexp(0, logits) - labels * logits
    weighted_loss = np.dot(weights, sample_loss) / weights.sum()
    regularisation = .5 * strength * np.dot(coefficients, coefficients)
    loss = weighted_loss + regularisation

    # Tell the optimiser how each coefficient should change to reduce the loss.
    predicted_scores = special.expit(logits)
    weighted_errors = weights * (predicted_scores - labels) / weights.sum()
    coefficient_gradient = features.T @ weighted_errors + strength * coefficients
    intercept_gradient = weighted_errors.sum()
    gradient = np.r_[coefficient_gradient, intercept_gradient]
    return float(loss), gradient


# %% 5. Training graphs and Gaussian-noise validation

def noise_experiment(windows, records, model, settings):
    """Repeat test predictions with known added noise; never refit the model."""
    tests = [item for item in windows if item["split"] == "test"]
    levels, repeats = settings["snr_db"], settings["repeats"]
    predictions = [[[] for _ in range(repeats)] for _ in levels]
    for ordinal, item in enumerate(tests):
        record = records[item["recording_id"]]
        clean, rows = select_window(record, item["start_s"], model["processing"]["window_seconds"])
        power = float(np.mean(np.var(clean[:, 1:], axis=0)))
        for repeat in range(repeats):
            generator = np.random.default_rng(np.random.SeedSequence([model["seed"], ordinal, repeat]))
            base_noise = generator.normal(size=clean[:, 1:].shape)
            base_noise -= base_noise.mean(axis=0)
            base_noise /= np.sqrt(np.mean(base_noise**2))
            for level_index, snr in enumerate(levels):
                noisy = clean.copy()
                noisy[:, 1:] += base_noise * np.sqrt(power / 10**(snr / 10))
                f, p, _ = window_psd(noisy, rows, record["fs"], model["processing"])
                vector, names, _ = extract_features(f, p, model["processing"])
                if names != model["feature_names"]:
                    raise ValueError("Noise test feature definitions changed.")
                predictions[level_index][repeat].append(float(damage_scores(vector[None, :], model)[0]))
    labels = np.asarray([item["label"] for item in tests])
    results = []
    for snr, scores_by_repeat in zip(levels, predictions):
        runs = [metrics(labels, scores, model["threshold"]) for scores in scores_by_repeat]
        keys = ["balanced_accuracy", "damage_recall", "healthy_false_positive_rate"]
        results.append({"snr_db": snr, "repeats": repeats, "metrics_by_repeat": runs,
            **{key + "_mean": float(np.mean([run[key] for run in runs])) for key in keys},
            **{key + "_std": float(np.std([run[key] for run in runs], ddof=0)) for key in keys}})
    return {"definition": "SNR = pooled demeaned selected-axis time-domain signal mean square / added noise mean square; all frequencies, not band SNR.",
        "method": "Equal noise variance per axis in expectation. The same seeded noise realisation is scaled across SNR levels. Only test windows are corrupted; model, reference and threshold stay fixed.",
        "limitation": "Synthetic Gaussian-noise sensitivity within the available recordings; not a minimum detectable chip mass or independent-flight result.",
        "results": results}


def make_training_figures(windows, records, model, report, output):
    """Save the separate example, confusion-matrix and noise figures."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    output = Path(output)
    examples = []
    for label in [0, 1]:
        candidates = [item for item in windows if item["label"] == label and item["split"] == "train"]
        identity = candidates[0]["recording_id"]
        candidates = [item for item in candidates if item["recording_id"] == identity]
        midpoint = records[identity]["data"][-1, 0] / 2
        example = min(candidates, key=lambda item: (abs((item["start_s"] + item["end_s"]) / 2 - midpoint), item["start_s"]))
        data, rows = select_window(records[identity], example["start_s"], model["processing"]["window_seconds"])
        first, last, bounds = example_fft_frame(data, rows, records[identity]["fs"], model["processing"])
        examples.append((example, data, first, last, bounds))

    # Matching scales on the full traces/spectra make the two conditions comparable.
    for example, data, first, last, bounds in examples:
        condition = "healthy" if example["label"] == 0 else "damaged"
        title = "Healthy" if example["label"] == 0 else "Damaged"
        color = "#2563eb" if example["label"] == 0 else "#dc2626"
        identity = example["recording_id"]
        fs = records[identity]["fs"]
        filename = records[identity]["audit"]["file"]
        frame_start, frame_end = data[first, 0], data[last - 1, 0] + 1 / fs
        for column, name in enumerate(AXES):
            fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
            trace, frame, spectrum, zoom = axes.flat
            lower = min(item[1][:, column + 1].min() for item in examples)
            upper = max(item[1][:, column + 1].max() for item in examples)
            padding = max((upper - lower) * .06, 1e-12)
            for left, right in zip(bounds[:-1], bounds[1:]):
                trace.plot(data[left:right, 0], data[left:right, column + 1], color=color, lw=.65, alpha=.8)
            trace.axvspan(frame_start, frame_end, color="#f59e0b", alpha=.35, label="Selected FFT frame")
            trace.set(title=f"Acceleration window: {example['start_s']:g}-{example['end_s']:g} s",
                xlabel="Recording time (s)", ylabel="Acceleration (m/s²)",
                xlim=(example["start_s"], example["end_s"]), ylim=(lower - padding, upper + padding))
            trace.legend(fontsize=8, loc="upper right")
            frame.plot(data[first:last, 0], data[first:last, column + 1], color=color, lw=1.1)
            frame.set(title=f"Selected FFT frame: {last - first} samples",
                xlabel="Recording time (s)", ylabel="Acceleration (m/s²)",
                xlim=(frame_start, frame_end), ylim=(lower - padding, upper + padding))
            frame.ticklabel_format(useOffset=False, axis="x")
            f, p = example["frequency"], example["psd"][:, column]
            spectrum.semilogy(f[1:], np.maximum(p[1:], np.finfo(float).tiny), color=color, lw=1.3)
            low_psd = min(item[0]["psd"][1:, column][item[0]["psd"][1:, column] > 0].min() for item in examples)
            high_psd = max(item[0]["psd"][1:, column].max() for item in examples)
            spectrum.set(title="Averaged spectrum and selected peak intervals", xlabel="Frequency (Hz)",
                ylabel="PSD ((m/s²)²/Hz)", xlim=(0, f[-1]), ylim=(low_psd / 2, high_psd * 2))
            peaks = [peak for peak in example["peak_diagnostics"][name]["peaks"] if peak["present"]]
            for index, peak in enumerate(peaks):
                spectrum.axvspan(peak["left_hz"], peak["right_hz"], color="#f59e0b", alpha=.3,
                    label="Selected peak interval" if index == 0 else None)
                spectrum.scatter(peak["frequency_hz"], peak["height"], color="#172554", s=24, zorder=3)
                spectrum.annotate(f"P{peak['rank']}", (peak["frequency_hz"], peak["height"]),
                    xytext=(4, 7), textcoords="offset points", fontsize=8)
            if peaks:
                spectrum.legend(fontsize=8, loc="upper right")
                peak = peaks[0]
                radius = max(3 * (f[1] - f[0]), 1.5 * peak["width_hz"])
                inside = (f >= max(f[1], peak["frequency_hz"] - radius)) & (f <= peak["frequency_hz"] + radius)
                zoom.plot(f[inside], p[inside], color=color, marker="o", markersize=4)
                zoom.axvspan(peak["left_hz"], peak["right_hz"], color="#f59e0b", alpha=.3, label="Selected interval")
                zoom.axvline(peak["frequency_hz"], color="#172554", ls="--", lw=1)
                zoom.set(title=f"Strongest peak: {peak['frequency_hz']:.2f} Hz",
                    xlabel="Frequency (Hz)", ylabel="PSD ((m/s²)²/Hz)",
                    xlim=(max(f[1], peak["frequency_hz"] - radius), min(f[-1], peak["frequency_hz"] + radius)))
                zoom.legend(fontsize=8, loc="upper right")
                zoom.text(.03, .95, f"Interval: {peak['left_hz']:.2f}-{peak['right_hz']:.2f} Hz\n"
                    f"Width: {peak['width_hz']:.2f} Hz", transform=zoom.transAxes, va="top", fontsize=9)
            else:
                zoom.axis("off")
                zoom.text(.5, .5, "No qualifying dominant peak in this window", ha="center", va="center")
            for ax in axes.flat:
                ax.grid(alpha=.15)
            fig.suptitle(f"{title} | {name.upper()} acceleration\n{filename}", fontsize=15)
            fig.supxlabel(f"Training window nearest recording midpoint. PSD averages {example['spectral_frames']} valid Hann FFT frames.\n"
                "Highlighted frame is an example; the spectrum uses all valid frames. Amber bands mark half-prominence peak intervals.", fontsize=9)
            fig.savefig(output / f"{condition}_{name}.png", dpi=160)
            plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.5, 5.5), constrained_layout=True)
    confusion = np.asarray(report["metrics"]["test"]["confusion_matrix_rows_true_columns_predicted"])
    ax.imshow(confusion, cmap="Blues", vmin=0, vmax=max(1, int(confusion.max())))
    ax.set(xticks=[0, 1], yticks=[0, 1], xticklabels=["Healthy", "Damaged"],
        yticklabels=["Healthy", "Damaged"], xlabel="Predicted condition", ylabel="Actual condition",
        title=f"Classification confusion matrix\n{confusion.trace()}/{confusion.sum()} held-out windows correct")
    for row in range(2):
        for column in range(2):
            ax.text(column, row, str(confusion[row, column]), ha="center", va="center", fontsize=30,
                color="white" if confusion[row, column] > confusion.max() / 2 else "#172554")
    fig.supxlabel(report["validation_design"].capitalize() + ".", fontsize=9)
    fig.savefig(output / "confusion_matrix.png", dpi=160)
    plt.close(fig)

    if report["noise_test"]:
        fig, ax = plt.subplots(figsize=(8, 5), constrained_layout=True)
        levels = report["noise_test"]["results"]
        for key, label, color in [("damage_recall", "Damage detected", "#dc2626"),
                ("healthy_false_positive_rate", "Healthy false alarms", "#d97706"),
                ("balanced_accuracy", "Balanced accuracy", "#2563eb")]:
            ax.plot([item["snr_db"] for item in levels], [100 * item[key + "_mean"] for item in levels],
                marker="o", label=label, color=color)
        ax.set(title="Noise sensitivity on held-out test windows", xlabel="SNR (dB; higher = less noise)",
            ylabel="Mean across seeded repeats (%)", ylim=(-3, 103))
        ax.legend(fontsize=9)
        ax.grid(alpha=.15)
        fig.supxlabel("Added Gaussian noise; model, baseline and decision cutoff remain fixed.", fontsize=9)
        fig.savefig(output / "noise_test.png", dpi=160)
        plt.close(fig)
    elif (output / "noise_test.png").exists():
        (output / "noise_test.png").unlink()
    if (output / "analysis.png").exists():
        (output / "analysis.png").unlink()


def training_summary(model, report):
    counts, result = report["split_counts"], report["metrics"]["test"]
    confusion = result["confusion_matrix_rows_true_columns_predicted"]
    lines = ["PROPELLER BLADE DAMAGE - TRAINING", "", "Model: combined X/Y, automatic peak features",
        f"Windows: {counts['train']} training | {counts['validation']} validation | {counts['test']} test | {counts['guard']} guard",
        f"Rejected windows: {report['rejected_count']}",
        f"Decision cutoff: {model['threshold']:.6f} (selected on validation data)",
        f"Validation balanced accuracy: {report['metrics']['validation']['balanced_accuracy']:.1%}",
        f"Test accuracy: {result['accuracy']:.1%}", f"Damage recall: {result['damage_recall']:.1%}",
        f"Healthy false alarms: {result['healthy_false_positive_rate']:.1%}",
        f"Test counts: healthy {confusion[0][0]}/{sum(confusion[0])} correct; damaged {confusion[1][1]}/{sum(confusion[1])} correct"]
    if report["noise_test"]:
        lines += ["", "ADDED GAUSSIAN NOISE - HELD-OUT WINDOWS", "SNR    Damage recall    Healthy false alarms    Balanced accuracy"]
        for item in report["noise_test"]["results"]:
            lines.append(f"{item['snr_db']:>3g} dB    {item['damage_recall_mean']:>8.1%}              "
                f"{item['healthy_false_positive_rate_mean']:>8.1%}             {item['balanced_accuracy_mean']:>8.1%}")
    lines += ["", "Evaluation: " + report["validation_design"] + ".",
        "Separate flights are needed to establish performance on unseen flights.",
        "Damage scores are uncalibrated; Gaussian-noise testing does not estimate detectable chip size.",
        "", "Saved: model.json | training_summary.txt | separate training PNG images"]
    return "\n".join(lines) + "\n"


# %% 6. Configuration and input checks

def active_axes(processing):
    return tuple(processing["axes"])


def load_settings(path):
    path = Path(path).resolve()
    config = json.loads(path.read_text(encoding="utf-8-sig"))
    processing = copy.deepcopy(PROCESSING)
    processing.update(config.get("processing", {}))
    processing["peak_features"] = {**PROCESSING["peak_features"],
        **config.get("processing", {}).get("peak_features", {})}
    config["processing"] = processing
    config["training"] = {**TRAINING, **config.get("training", {})}
    config["noise_test"] = {**NOISE, **config.get("noise_test", {})}
    config["excel_format"] = {**copy.deepcopy(EXCEL_FORMAT), **config.get("excel_format", {})}
    config.setdefault("data_folder", "data")
    config.setdefault("output_folder", "results")
    fmt, proc, train = config["excel_format"], config["processing"], config["training"]
    if fmt["time_unit"] != "s" or fmt["acceleration_unit"] != "m/s^2":
        raise ValueError("Declare numeric seconds and acceleration in m/s^2 in input.json.")
    axes = active_axes(proc)
    if axes != tuple(AXES) or proc["feature_method"] != "dominant_peaks":
        raise ValueError("This project uses dominant-peak features from X and Y together.")
    required = {"time", *axes}
    if not required <= set(fmt["columns"]) or not set(fmt["columns"]) <= {"time", *AXES}:
        raise ValueError("Excel column mapping must contain time and every selected axis.")
    if len({fmt["columns"][key] for key in required}) != len(required) or int(fmt["header_row"]) < 1:
        raise ValueError("Specify distinct selected column headers and a positive header_row.")
    if proc["window_seconds"] <= 0 or int(proc["fft_samples"]) != proc["fft_samples"] or proc["fft_samples"] < 32:
        raise ValueError("window_seconds must be positive; fft_samples must be an integer >=32.")
    if not 0 <= proc["overlap_fraction"] < 1 or proc["gap_factor"] <= 1:
        raise ValueError("overlap_fraction must be in [0,1); gap_factor must exceed 1.")
    if not 0 < proc["max_relative_jitter"] < 1:
        raise ValueError("max_relative_jitter must be between zero and one.")
    for name in ["min_sample_coverage", "min_frame_coverage"]:
        if not 0 < proc[name] <= 1:
            raise ValueError(f"{name} must be in (0,1].")
    peaks = proc["peak_features"]
    for key in ["count", "min_separation_bins"]:
        if isinstance(peaks[key], bool) or int(peaks[key]) != peaks[key] or peaks[key] < 1:
            raise ValueError(f"peak_features.{key} must be a positive integer.")
    if not 0 < peaks["min_prominence_fraction"] < 1 or not np.isfinite(peaks["noise_floor_multiplier"]) or peaks["noise_floor_multiplier"] <= 0:
        raise ValueError("Peak prominence fraction must be in (0,1); noise multiplier must be positive.")
    if not 0 < peaks["max_sampling_rate_change_fraction"] < 1:
        raise ValueError("Sampling-rate tolerance must be in (0,1).")
    if not 0 < train["train_fraction"] < 1 or not 0 < train["validation_fraction"] < 1:
        raise ValueError("Training and validation fractions must be in (0,1).")
    if train["train_fraction"] + train["validation_fraction"] >= 1:
        raise ValueError("Leave a positive test fraction.")
    for name in ["guard_windows", "persistence_windows", "seed"]:
        if int(train[name]) != train[name] or train[name] < (1 if name == "persistence_windows" else 0):
            raise ValueError(f"{name} must be a nonnegative integer (persistence >=1).")
    for name in ["l2_strength", "normalisation_std_floor", "normalisation_relative_floor"]:
        if not np.isfinite(train[name]) or train[name] <= 0:
            raise ValueError(f"{name} must be finite and positive.")
    noise = config["noise_test"]
    if (int(noise["repeats"]) != noise["repeats"] or noise["repeats"] < 1
            or not noise["snr_db"] or not np.isfinite(noise["snr_db"]).all()):
        raise ValueError("Specify finite noise SNR levels and at least one repeat.")
    ids, files, flight_splits = set(), set(), {}
    for item in config["recordings"]:
        if item["id"] in ids or item["file"] in files or not item["flight_id"]:
            raise ValueError("Recording IDs/files must be unique, with a flight_id for each.")
        if item["label"] not in [0, 1] or isinstance(item["label"], bool):
            raise ValueError("Labels must be 0 (undamaged) or 1 (damaged).")
        split = item["split"]
        if split not in ["chronological", "train", "validation", "test"]:
            raise ValueError("split must be chronological, train, validation or test.")
        prior = flight_splits.setdefault(item["flight_id"], split)
        if prior != split:
            raise ValueError("Recordings from the same flight_id cannot span different splits.")
        ids.add(item["id"])
        files.add(item["file"])
    config["_base"] = str(path.parent)
    return config


def split_for_window(index, count, item, train):
    if item["split"] != "chronological":
        return item["split"]
    first = int(np.floor(count * train["train_fraction"]))
    second = int(np.floor(count * (train["train_fraction"] + train["validation_fraction"])))
    if index < first:
        return "train"
    if index < first + train["guard_windows"]:
        return "guard"
    if index < second:
        return "validation"
    if index < second + train["guard_windows"]:
        return "guard"
    return "test"


def check_sampling_support(rate, support, name="Recording"):
    if support and not support["training_min_hz"] * (1 - support["tolerance_fraction"]) <= rate <= support["training_max_hz"] * (1 + support["tolerance_fraction"]):
        raise ValueError(f"{name}: sampling rate differs from the peak model's trained FFT resolution. Use compatible sampling or retrain with representative recordings.")


def load_recordings(config):
    folder = (Path(config["_base"]) / config["data_folder"]).resolve()
    records, hashes = {}, set()
    for item in config["recordings"]:
        path = (folder / item["file"]).resolve()
        if not path.is_relative_to(folder):
            raise ValueError("Recording paths must stay inside data_folder.")
        print(f"Reading {item['file']} ...", flush=True)
        record = read_excel(path, config["excel_format"], config["processing"], item["id"])
        if record["audit"]["sha256"] in hashes:
            raise ValueError("Duplicate workbook contents cannot count as independent recordings.")
        hashes.add(record["audit"]["sha256"])
        records[item["id"]] = record
    return records


def prepare_training_output(config):
    """Prepare the results folder without overwriting source workbooks."""
    output = (Path(config["_base"]) / config["output_folder"]).resolve()
    data_folder = (Path(config["_base"]) / config["data_folder"]).resolve()
    if output == data_folder or output.is_relative_to(data_folder) or data_folder.is_relative_to(output):
        raise ValueError("Keep output_folder separate from data_folder.")
    output.mkdir(parents=True, exist_ok=True)
    for name in ["model.json", "training_summary.txt", "analysis.png", *TRAINING_IMAGES]:
        existing = output / name
        if existing.exists():
            try:
                with existing.open("r+b"):
                    pass
            except PermissionError as error:
                raise ValueError(f"Close {existing.name} in other applications before training.") from error
    return output


def select_excel_file():
    """Optional local file selection; --file remains available without a desktop."""
    try:
        from tkinter import Tk, TclError, filedialog
    except ImportError as error:
        raise ValueError('File picker unavailable. Use: python pipeline.py predict --file "path/to/recording.xlsx"') from error
    root = None
    try:
        root = Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        chosen = filedialog.askopenfilename(parent=root, title="Select accelerometer Excel recording",
            initialdir=str(HERE / "data"), filetypes=[("Excel workbook", "*.xlsx"), ("All files", "*.*")])
    except (TclError, RuntimeError) as error:
        # Tk may be installed while no graphical display is available.
        raise ValueError('File picker unavailable. Use --file followed by the Excel path.') from error
    finally:
        if root is not None:
            try:
                root.destroy()
            except TclError:
                pass
    return Path(chosen) if chosen else None


# %% 7. Model saving and loading

def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_model(config, records, training_windows, names, reference, classifier):
    """Package fitted weights and settings in the existing model.json format."""
    training_ids = {item["recording_id"] for item in training_windows}
    rates = [records[identity]["fs"] for identity in training_ids]
    return {"version": MODEL_VERSION, "model_type": "regularised_logistic", "feature_names": names,
        "processing": copy.deepcopy(config["processing"]), "excel_format": copy.deepcopy(config["excel_format"]),
        "healthy_reference": reference, "classifier": classifier, "threshold": .5,
        "persistence_windows": config["training"]["persistence_windows"], "seed": config["training"]["seed"],
        "sampling_support": {"training_min_hz": min(rates), "training_max_hz": max(rates),
            "tolerance_fraction": config["processing"]["peak_features"]["max_sampling_rate_change_fraction"]},
        "training_recording_hashes": [records[item["id"]]["audit"]["sha256"] for item in config["recordings"]
            if item["split"] in ["chronological", "train"]],
        "reproducibility": {"source_sha256": file_hash(Path(__file__)),
            "settings": {key: value for key, value in config.items() if key != "_base"},
            "versions": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__},
            "recordings": [record["audit"] for record in records.values()]}}


def validate_score_model(model):
    count = len(model["feature_names"])
    if (count == 0 or len(set(model["feature_names"])) != count
            or len(model["classifier"]["coefficients"]) != count
            or any(len(model["healthy_reference"][key]) != count for key in ["mean", "std", "scale"])
            or np.any(np.asarray(model["healthy_reference"]["scale"]) <= 0)):
        raise ValueError("Saved model dimensions or normalisation scales are invalid.")
    numbers = [*model["classifier"]["coefficients"], model["classifier"]["intercept"], model["threshold"],
        *model["healthy_reference"]["mean"], *model["healthy_reference"]["std"], *model["healthy_reference"]["scale"]]
    if (not np.isfinite(numbers).all() or not 0 <= model["threshold"] <= 1
            or np.any(np.asarray(model["healthy_reference"]["std"]) < 0)):
        raise ValueError("Saved model contains non-finite values or an invalid threshold.")
    active = model["healthy_reference"].get("active_features")
    if active is not None and (len(active) != count or any(not isinstance(value, bool) for value in active)):
        raise ValueError("Saved active-feature mask is invalid.")


def load_model(path):
    model = json.loads(Path(path).read_text(encoding="utf-8"))
    if model["version"] != MODEL_VERSION or model["model_type"] != "regularised_logistic":
        raise ValueError("Use the current results/model.json, or retrain with this version.")
    if model["processing"]["axes"] != list(AXES) or model["processing"]["feature_method"] != "dominant_peaks":
        raise ValueError("The saved model must use combined X/Y dominant-peak features.")
    validate_score_model(model)
    support = model["sampling_support"]
    if (not np.isfinite(list(support.values())).all() or support["training_min_hz"] <= 0
            or support["training_max_hz"] < support["training_min_hz"] or not 0 < support["tolerance_fraction"] < 1):
        raise ValueError("Saved model sampling-rate limits are invalid.")
    persistence = model["persistence_windows"]
    if int(persistence) != persistence or persistence < 1:
        raise ValueError("Saved alarm persistence must be a positive integer.")
    return model


# %% 8. Self-test and command-line entry

def self_test():
    proc = copy.deepcopy(PROCESSING)
    proc.update(window_seconds=2, fft_samples=256)
    fs = 1024.
    t = np.arange(2048) / fs
    tone = .2 * np.sin(2 * np.pi * 160 * t) + .1 * np.sin(2 * np.pi * 320 * t)
    data, rows = np.column_stack([t, tone, tone]), np.arange(2, 2050)
    f, p, _ = window_psd(data, rows, fs, proc)
    f_ref, p_ref = signal.welch(data[:, 1:], fs=fs, window="hann", nperseg=256,
        noverlap=128, detrend="constant", scaling="density", axis=0)
    np.testing.assert_allclose(f, f_ref)
    np.testing.assert_allclose(p, p_ref, rtol=1e-12, atol=1e-15)
    features, names, peaks = extract_features(f, p, proc)
    assert len(features) == 36 and peaks["x"]["peaks"][0]["frequency_hz"] == 160.
    assert peaks["x"]["peaks"][0]["left_hz"] < 160 < peaks["x"]["peaks"][0]["right_hz"]
    gap_data, gap_rows = data.copy(), rows.copy()
    gap_data[900:, 0] += 1.
    _, gap_psd, _ = window_psd(gap_data, gap_rows, fs, proc)
    frames = [signal.periodogram(data[offset:offset + 256, 1:], fs=fs, window="hann",
        detrend="constant", scaling="density", axis=0)[1]
        for lo, hi in [(0, 900), (900, 2048)] for offset in range(lo, hi - 256 + 1, 128)]
    np.testing.assert_allclose(gap_psd, np.mean(frames, axis=0), rtol=1e-12, atol=1e-15)
    examples = np.array([[0., 1.], [0., 2.], [0., 3.], [8., 9.]])
    labels = np.array([0, 0, 0, 1])
    reference = healthy_reference(examples, labels, TRAINING)
    np.testing.assert_allclose(reference["mean"], [0., 2.])
    assert reference["active_features"] == [False, True]
    assert normalise(examples, reference)[3, 0] == 0.
    assert choose_threshold([0, 0, 1, 1], [.1, .2, .8, .9]) == .5
    fitted = fit_classifier(normalise(examples, reference), labels, .1)
    assert fitted["optimisation_success"]
    model = {"healthy_reference": reference, "classifier": fitted, "threshold": .5, "persistence_windows": 2}
    windows = [{"recording_id": "test", "split": "prediction", "window_index": index,
        "start_s": index * 10., "end_s": (index + 1) * 10., "features": examples[3]}
        for index in [0, 1, 3]]
    apply_predictions(windows, model)
    assert [item["sustained_alarm"] for item in windows] == [False, True, False]
    result = recording_assessment(windows, [], {"discarded_tail_seconds": 0.}, PROCESSING, 2)
    assert result["first_alarm_confirmed_at_s"] == 20.
    short = recording_assessment([], [], {"discarded_tail_seconds": 5.}, PROCESSING, 2)
    assert short["status"] == "insufficient_data"
    print("Checks passed: PSD, adaptive peaks, gap isolation, healthy-only scaling, cutoff selection and alarm persistence.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    training = commands.add_parser("train", help="Train and save a short summary and separate training images.")
    training.add_argument("--config", type=Path, default=HERE / "input.json")
    training.add_argument("--verbose", action="store_true", help="Show validation cutoff trials.")
    prediction = commands.add_parser("predict", help="Check one Excel file using the saved model.")
    prediction.add_argument("--file", type=Path, help="Omit to open a file picker.")
    prediction.add_argument("--model", type=Path)
    prediction.add_argument("--output", type=Path, help="Folder for prediction.txt (overwritten each run).")
    commands.add_parser("self-test", help="Run the small synthetic checks without reading workbooks.")
    args = parser.parse_args()
    if args.command == "self-test":
        self_test()
    elif args.command == "train":
        train_pipeline(load_settings(args.config), args.verbose)
    else:
        path = args.file or select_excel_file()
        if path is None:
            print("File selection cancelled.")
            return
        model_path = args.model
        if model_path is None:
            config = load_settings(HERE / "input.json")
            model_path = Path(config["_base"]) / config["output_folder"] / "model.json"
        predict_file(path, model_path, args.output or model_path.resolve().parent)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, TypeError) as error:
        print(f"Input error: {error}", file=sys.stderr)
        sys.exit(1)
