# UAV Propeller Damage Detection

Detect possible propeller blade damage from recorded accelerometer data using frequency analysis and logistic regression.

The program reads an Excel file containing time, X acceleration and Y acceleration. It divides the recording into windows, measures vibration features, compares them with a healthy training reference, and assesses whether the recording contains sustained signs of blade damage.

This README covers the propeller damage detection module only. The classifier has two labels: **undamaged (0)** and **damaged (1)**. It does not identify which blade is damaged, distinguish individual damage types, or estimate chip size. The current classifier uses **X and Y together**; Z is not a model input.

## 1. Files in this project

| File or folder | Purpose |
| --- | --- |
| `pipeline.py` | Reading Excel, signal processing, feature extraction, training, prediction and plotting in one Python file. |
| `input.json` | Settings for the original healthy and two damaged recordings. |
| `input_dronepropa.json` | Settings and fixed flight assignments for the 130 DronePropA recordings. |
| `data/` | Original Excel recordings and dataset folders. |
| `data/DronePropA_excel/` | DronePropA recordings converted to time, X and Y acceleration. |
| `results/` | Model, training summary and graphs from `input.json`. |
| `results_dronepropa/` | Model, training summary and graphs from `input_dronepropa.json`. |
| `output/pdf/Propeller_Damage_Pipeline_Formulas_and_Workflow.pdf` | Detailed explanation of the workflow and equations. |

Training generates the results folders if needed. Dataset files must be present at the locations specified in the selected configuration; the program does not download them automatically.

## 2. Installation

Use Python 3.12 for the tested setup. Open a terminal in the folder containing `pipeline.py`.

For example, on Windows after downloading or cloning the repository:

```powershell
cd "C:\path\to\your\repository"
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install numpy==2.4.2 scipy==1.17.0 openpyxl==3.1.5 matplotlib==3.10.8
```

These are the versions used in the current local environment. NumPy handles arrays, SciPy handles signal processing and logistic regression optimisation, openpyxl reads Excel files, and Matplotlib creates the training graphs. Scikit-learn is not required.

Run the built-in synthetic checks:

```powershell
python pipeline.py self-test
```

This checks the PSD calculation against Welch's method, peak extraction, handling of gaps, healthy-reference scaling, threshold selection and consecutive-window alarms. It does not train on the datasets or establish real-world detection accuracy.

## 3. Excel input format

Use an `.xlsx` workbook with a worksheet named `Sheet1` and these headers in the first row:

| Time (s) | X Acceleration | Y Acceleration |
| --- | --- | --- |
| 0.000 | -0.0670 | -0.1245 |
| 0.001 | -0.0575 | -0.1149 |
| 0.002 | -0.0766 | -0.1293 |

- Time must be numeric **seconds**, and acceleration must be numeric **m/s²**.
- Each row represents one sample. Timestamps must increase strictly, without duplicates or resets.
- A different sheet name or column headers can be mapped in the configuration before training.
- Additional columns, including Z acceleration, can remain in the workbook; only the mapped time, X and Y columns are read.
- Sampling rate is calculated from the timestamps. Within uninterrupted sections, timing jitter must stay within the configured limit, which defaults to 1%.

Recordings can have different lengths; they do not need to contain exactly 420 seconds or a fixed number of samples. With the default settings, only complete 10-second decision windows are analysed. The final partial window is reported but not classified.

A recording normally needs at least **20 seconds of accepted, consecutive data** for the default recording-level assessment. Invalid numeric entries cause an input error; complete windows with insufficient usable coverage are rejected. FFT frames are never joined across detected gaps or skipped Excel rows.

## 4. Train the model

### Original recordings

Make sure `data/` contains the files listed in `input.json`:

- `Healthy.xlsx`
- `Damaged Top Right Blade.xlsx`
- `Damaged Bottom Right Blade.xlsx`

Then run:

```powershell
python pipeline.py train
```

Results are saved in `results/`. To print each validation threshold trial:

```powershell
python pipeline.py train --verbose
```

### DronePropA recordings

Place the 130 converted Excel files in `data/DronePropA_excel/`, then run:

```powershell
python pipeline.py train --config input_dronepropa.json
```

Results are saved separately in `results_dronepropa/`. This configuration assigns 78 flights to training, 26 to validation and 26 to testing. All windows from a flight remain in its assigned split.

### Your own training data

Copy a configuration to a new JSON file, change `data_folder` and `output_folder`, and update its `recordings` list. Each recording entry has this form:

```json
{
  "id": "healthy_flight_01",
  "file": "healthy_flight_01.xlsx",
  "label": 0,
  "flight_id": "flight_01",
  "split": "train"
}
```

Use label `0` for undamaged and `1` for damaged. For separate-flight evaluation, assign each flight to `train`, `validation` or `test`. Use the same `flight_id` for recordings belonging to the same flight and keep them in the same split. Both labels must be represented in every split after quality checks, with at least two healthy training windows.

Run the new configuration with:

```powershell
python pipeline.py train --config my_input.json
```

The program reads only files listed in `recordings`. Data and output folder paths are resolved relative to the configuration file. Re-running training replaces the generated model, summary and graphs in that output folder, so use a different output folder to preserve an earlier experiment.

## 5. Predict a new recording

Use the model trained on data representative of the new recording.

For the original model:

```powershell
python pipeline.py predict --file "C:\path\to\new_flight.xlsx" --model results/model.json
```

For the DronePropA model:

```powershell
python pipeline.py predict --file "C:\path\to\new_flight.xlsx" --model results_dronepropa/model.json
```

To choose the Excel file through a file picker:

```powershell
python pipeline.py predict --model results_dronepropa/model.json
```

Running `python pipeline.py predict` without a model argument uses the output folder configured in **`input.json`**. It does not automatically choose the most recently trained model.

Prediction prints a short result and saves `prediction.txt` beside the selected model. To save it elsewhere:

```powershell
python pipeline.py predict --file "C:\path\to\new_flight.xlsx" --model results_dronepropa/model.json --output prediction_results
```

Each run replaces `prediction.txt` in the selected output folder. Prediction does **not** retrain, update the healthy reference, or adjust the threshold.

## 6. What the code does

```text
Excel: time + X/Y acceleration
             |
     Check input and sampling
             |
    Complete 10-second windows
             |
  Hann FFT frames -> averaged PSD
             |
   Automatic spectral features
             |
  Saved healthy-reference scaling
             |
      Logistic damage score
             |
   Saved threshold + persistence
             |
      Recording assessment
```

### Signal processing and features

Inside each decision window, the program uses **250-sample FFT frames with 50% overlap**. It subtracts each frame's mean, applies a Hann window, calculates a one-sided power spectral density (PSD), and averages the valid frame spectra. At 1,000 Hz sampling, each FFT frame lasts 0.25 seconds and the frequency-bin spacing is 4 Hz.

FFT reveals frequency components. PSD expresses vibration power per unit frequency; integrating it over an interval gives band power. These are steps in the same analysis, rather than separate classifiers.

The feature extractor examines the available positive-frequency spectrum, excluding DC. It does **not** assume damage lies in a fixed 200–300 Hz band. For each axis, it selects up to three qualifying dominant peaks using prominence and minimum separation, then measures intervals at half prominence.

| Feature | What it describes |
| --- | --- |
| Total positive-frequency power | Overall vibration energy. |
| Spectral entropy | How widely power is distributed across frequency bins. |
| Spectral flatness | Whether the spectrum is concentrated in tones or spread more broadly. |
| Peak height and prominence | Peak strength and how much it stands above its surrounding spectrum. |
| Peak width | Frequency spread of the selected peak. |
| Peak band power and power fraction | Energy around the peak and its share of total vibration power. |

There are three global features plus five features for each of three peaks: **18 per axis, 36 across X and Y**. Missing peak ranks receive zero-valued peak features. Peak centre frequencies are shown in the graphs but are not classifier inputs.

Healthy propellers also vibrate. Damage can alter spectral energy, peak strength, width and distribution, but a large peak alone does not prove damage. The classifier learns combinations of these features from labelled healthy and damaged examples.

### Normalisation and logistic regression

For each feature, training calculates a mean and standard deviation using **healthy training windows only**:

```text
scaled feature = (feature - healthy training mean) / saved scale
damage score   = sigmoid(weighted sum of scaled features + intercept)
```

The saved scale is the healthy standard deviation with a small numerical floor. Features with no usable variation in the healthy training reference are ignored. This is feature normalisation; the program does not divide each 10-second acceleration waveform by its own standard deviation or normalise using RPM.

A class-balanced, L2-regularised logistic regression learns the feature weights from the training set. Validation then selects the decision threshold that maximises balanced accuracy, with ties favouring a threshold closer to 0.5. The held-out test set evaluates the resulting fixed model.

The damage score lies between 0 and 1, but it is **not a calibrated probability or confidence percentage**. The threshold is saved in `model.json` and can differ after retraining. There is no `--threshold` prediction option. To experiment with a manual threshold, copy the model JSON, change its top-level `threshold` value to a number between 0 and 1, and predict using that copy. Evaluate such changes on validation data rather than tuning against the test set.

### Recording-level decision

A window is flagged when its score is greater than or equal to the saved threshold. By default, **two consecutive flagged windows** confirm a sustained alarm.

| Output | Meaning |
| --- | --- |
| `POSSIBLE BLADE DAMAGE` | A sustained alarm occurred in the analysed windows. |
| `NO BLADE DAMAGE DETECTED` | Sufficient consecutive data was accepted, with no positive windows and no rejected complete windows. |
| `INCONCLUSIVE - REVIEW REQUIRED` | Isolated positive windows occurred without a sustained alarm. |
| `INCONCLUSIVE - INCOMPLETE COVERAGE` | Accepted windows had no positive flags, but some complete windows were rejected. |
| `INSUFFICIENT DATA` | There was insufficient consecutive accepted data for the assessment. |

The result includes window counts, flagged intervals, the first confirmed alarm where applicable, and any unanalysed tail. It applies to the analysed recording, not to every UAV component or its flightworthiness.

## 7. Training outputs and validation

| Output | Contents |
| --- | --- |
| `model.json` | Feature definitions, healthy reference, learned weights, threshold, processing settings and reproducibility metadata. |
| `training_summary.txt` | Split counts, validation/test performance and noise sensitivity. |
| `confusion_matrix.png` | Actual versus predicted test-window labels; rows are actual labels and columns are predictions. |
| `healthy_x.png`, `healthy_y.png` | Separate healthy-axis examples showing the decision window, an FFT frame, averaged PSD and strongest-peak detail. |
| `damaged_x.png`, `damaged_y.png` | Corresponding damaged-axis examples. |
| `noise_test.png` | Performance under added Gaussian noise, when enabled. |

Example plots use an accepted training window nearest the recording midpoint from the first available recording of each class. They are illustrative; the confusion matrix uses held-out test windows.

The currently saved runs report:

| Configuration | Evaluation design | Test windows | Accuracy | Damage recall | Healthy false-positive rate |
| --- | --- | ---: | ---: | ---: | ---: |
| `input.json` | Reserved time sections of the same three recordings | 24 | 100.0% | 100.0% | 0.0% |
| `input_dronepropa.json` | Whole-flight holdout | 178 | 62.9% | 57.7% | 25.5% |

The original configuration uses chronological sections, approximately 60% training, 20% validation and 20% test, with guard windows excluded at the boundaries. Its perfect score does not demonstrate performance on independent flights. The DronePropA result tests separate flights and shows the current model's more limited generalisation. These are **window-level** metrics, not accuracy measurements for the recording-level persistence rule. Check the generated summaries for results after retraining.

Noise testing adds seeded Gaussian noise to held-out test windows at 30, 20, 10 and 0 dB SNR, with three repeats by default. Higher SNR means less added noise. The reference, model and threshold stay fixed. SNR uses pooled, demeaned X/Y signal power divided by added noise power. This measures sensitivity to synthetic noise; it does not establish the minimum detectable chip mass or damage size.

## 8. Practical limits and reproducibility

- Sensor position, axis orientation, airframe, propeller, operating speed and flight manoeuvres can change the vibration features. Train and validate on representative conditions before applying the model to another setup.
- The code checks that prediction sampling rate lies within the trained sampling-rate range, expanded by 5% by default. It does not automatically resample data or perform RPM-based order tracking.
- Mean removal suppresses constant offsets, but the pipeline does not explicitly separate flight manoeuvres from vibration. There is no universal frequency boundary that guarantees this separation.
- Keep flights independent across training, validation and testing. A prediction on a workbook used in training is a consistency check, and the program reports this reuse.
- The model stores settings, random seed, source-code hash, recording hashes and Python/NumPy/SciPy versions. Keep the same inputs, configuration and software versions for comparable reruns.

### DronePropA attribution

The optional DronePropA data is an external experimental dataset, not data generated by this project. Its healthy flights are mapped to label 0; edge-cut, crack and surface-cut cases are combined into label 1. The converted Excel files retain the original first-accelerometer time and acceleration measurements.

Source: Mohamed AA Ismail, Mohssen E Elshaar, Ayman Abdallah and Quan Quan, *DronePropA: Motion Trajectories Dataset for Commercial Drones with Defective Propellers*, version 1, Mendeley Data, DOI: **10.17632/ftdyxrr3c5.1**. The source dataset is distributed under **CC BY 4.0**. Preserve attribution when sharing the converted data.

[Download and dataset details](https://data.mendeley.com/datasets/ftdyxrr3c5/1)
