# Graph collection

There are 20 unique scientific figures in six folders. GRAPH_OVERVIEW.png is a thumbnail index, not an additional analytical result. For descriptions and full-image links, open ../docs/graph_gallery.html or ../docs/GRAPH_INDEX.md.

| Folder | Figures | Contents |
| --- | ---: | --- |
| 01_force_models | 2 | Illustrative mass-imbalance and wobble forces |
| 02_healthy_vs_damaged | 4 | Measured healthy/damaged time signals, PSD and RMS |
| 03_top_right_three_conditions | 2 | Healthy, damaged and added-mass PSD/RMS comparison |
| 04_all_five_conditions | 4 | All-five PSDs and 15-second window distributions |
| 05_sine_gaussian_baseline | 4 | Healthy/damaged waveform and spectral model overlays |
| 06_mass_damage_sine_gaussian | 4 | Added mass, sine/Gaussian model and damage FFT/PSD overlays |

All original images are preserved byte for byte. Eight exact verification-run duplicate copies remain in ../archive/legacy_workspace/work. Different panel layouts of the same analysis are kept because they are distinct figures.
